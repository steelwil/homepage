-- MySQL dump 10.11
--
-- Host: localhost    Database: frogzane_copp1
-- ------------------------------------------------------
-- Server version	5.0.51a-community

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cpg_albums`
--

DROP TABLE IF EXISTS `cpg_albums`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cpg_albums` (
  `aid` int(11) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL default '',
  `description` text NOT NULL,
  `visibility` int(11) NOT NULL default '0',
  `uploads` enum('YES','NO') NOT NULL default 'NO',
  `comments` enum('YES','NO') NOT NULL default 'YES',
  `votes` enum('YES','NO') NOT NULL default 'YES',
  `pos` int(11) NOT NULL default '0',
  `category` int(11) NOT NULL default '0',
  `thumb` int(11) NOT NULL default '0',
  `keyword` varchar(50) default NULL,
  `alb_password` varchar(32) default NULL,
  `alb_password_hint` text,
  PRIMARY KEY  (`aid`),
  KEY `alb_category` (`category`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cpg_albums`
--

LOCK TABLES `cpg_albums` WRITE;
/*!40000 ALTER TABLE `cpg_albums` DISABLE KEYS */;
INSERT INTO `cpg_albums` (`aid`, `title`, `description`, `visibility`, `uploads`, `comments`, `votes`, `pos`, `category`, `thumb`, `keyword`, `alb_password`, `alb_password_hint`) VALUES (1,'Holiday','',0,'YES','YES','YES',101,2,16,'Donette','',''),(4,'Family','',0,'YES','YES','YES',102,2,17,'Donette','',''),(6,'First two years','',0,'NO','YES','YES',103,2,1,'Donette','',''),(7,'Special moments','',0,'YES','YES','YES',104,2,23,'Donette','',''),(8,'2 and up','',0,'YES','YES','YES',105,2,137,'Donette','',''),(9,'Homeschool','',0,'YES','YES','YES',100,2,117,'frogzane','',''),(10,'Baby Bell','',0,'NO','YES','YES',106,2,0,NULL,NULL,NULL),(11,'William&#39;s Album','',0,'NO','YES','YES',1,10003,0,NULL,NULL,NULL);
/*!40000 ALTER TABLE `cpg_albums` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpg_banned`
--

DROP TABLE IF EXISTS `cpg_banned`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cpg_banned` (
  `ban_id` int(11) NOT NULL auto_increment,
  `user_id` int(11) default NULL,
  `ip_addr` tinytext,
  `expiry` datetime default NULL,
  `brute_force` tinyint(5) NOT NULL default '0',
  PRIMARY KEY  (`ban_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cpg_banned`
--

LOCK TABLES `cpg_banned` WRITE;
/*!40000 ALTER TABLE `cpg_banned` DISABLE KEYS */;
/*!40000 ALTER TABLE `cpg_banned` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpg_bridge`
--

DROP TABLE IF EXISTS `cpg_bridge`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cpg_bridge` (
  `name` varchar(40) NOT NULL default '0',
  `value` varchar(255) NOT NULL default '',
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cpg_bridge`
--

LOCK TABLES `cpg_bridge` WRITE;
/*!40000 ALTER TABLE `cpg_bridge` DISABLE KEYS */;
INSERT INTO `cpg_bridge` (`name`, `value`) VALUES ('short_name',''),('license_number',''),('db_database_name',''),('db_hostname',''),('db_username',''),('db_password',''),('full_forum_url',''),('relative_path_of_forum_from_webroot',''),('relative_path_to_config_file',''),('logout_flag',''),('use_post_based_groups',''),('cookie_prefix',''),('table_prefix',''),('user_table',''),('session_table',''),('group_table',''),('group_relation_table',''),('group_mapping_table',''),('use_standard_groups','1'),('validating_group',''),('guest_group',''),('member_group',''),('admin_group',''),('banned_group',''),('global_moderators_group',''),('recovery_logon_failures','0'),('recovery_logon_timestamp','');
/*!40000 ALTER TABLE `cpg_bridge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpg_categories`
--

DROP TABLE IF EXISTS `cpg_categories`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cpg_categories` (
  `cid` int(11) NOT NULL auto_increment,
  `owner_id` int(11) NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `description` text NOT NULL,
  `pos` int(11) NOT NULL default '0',
  `parent` int(11) NOT NULL default '0',
  `thumb` int(11) NOT NULL default '0',
  PRIMARY KEY  (`cid`),
  KEY `cat_parent` (`parent`),
  KEY `cat_pos` (`pos`),
  KEY `cat_owner_id` (`owner_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cpg_categories`
--

LOCK TABLES `cpg_categories` WRITE;
/*!40000 ALTER TABLE `cpg_categories` DISABLE KEYS */;
INSERT INTO `cpg_categories` (`cid`, `owner_id`, `name`, `description`, `pos`, `parent`, `thumb`) VALUES (1,0,'User galleries','This category contains albums that belong to Coppermine users.',2,0,0),(2,0,'Family ','These are the family photos ',0,0,0);
/*!40000 ALTER TABLE `cpg_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpg_comments`
--

DROP TABLE IF EXISTS `cpg_comments`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cpg_comments` (
  `pid` mediumint(10) NOT NULL default '0',
  `msg_id` mediumint(10) NOT NULL auto_increment,
  `msg_author` varchar(25) NOT NULL default '',
  `msg_body` text NOT NULL,
  `msg_date` datetime NOT NULL default '0000-00-00 00:00:00',
  `msg_raw_ip` tinytext,
  `msg_hdr_ip` tinytext,
  `author_md5_id` varchar(32) NOT NULL default '',
  `author_id` int(11) NOT NULL default '0',
  PRIMARY KEY  (`msg_id`),
  KEY `com_pic_id` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=15706 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cpg_comments`
--

LOCK TABLES `cpg_comments` WRITE;
/*!40000 ALTER TABLE `cpg_comments` DISABLE KEYS */;
INSERT INTO `cpg_comments` (`pid`, `msg_id`, `msg_author`, `msg_body`, `msg_date`, `msg_raw_ip`, `msg_hdr_ip`, `author_md5_id`, `author_id`) VALUES (115,1,'Guest_Boo','I wish I had a train like that :cry:','2008-07-18 17:20:06','198.54.202.182','41.240.190.115','1955525ba371839667f1704beed6c0b8',0),(52,2,'Guest_Anon',':-)','2008-07-28 11:18:05','196.35.158.178','156.8.254.130','9e6c23b350d97942dccfe2c143e881ad',0),(113,3,'Guest_Chantal','I really love this photo :lol:','2008-08-07 11:49:58','196.207.32.37','41.31.187.2','734cb3e6a8b444972e768264c1d1adab',0),(137,4888,'Guest_Christine','oh dear you guys have a troll(I mean the comments, that are not making any sense!)','2008-09-04 13:20:32','65.95.101.246','65.95.101.246','ca6673b565e236997f339174611cdd49',0);
/*!40000 ALTER TABLE `cpg_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpg_config`
--

DROP TABLE IF EXISTS `cpg_config`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cpg_config` (
  `name` varchar(40) NOT NULL default '',
  `value` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cpg_config`
--

LOCK TABLES `cpg_config` WRITE;
/*!40000 ALTER TABLE `cpg_config` DISABLE KEYS */;
INSERT INTO `cpg_config` (`name`, `value`) VALUES ('albums_per_page','12'),('album_list_cols','2'),('display_pic_info','0'),('alb_list_thumb_size','50'),('allowed_mov_types','ALL'),('allowed_doc_types','doc/txt/rtf/pdf/xls/pps/ppt/zip/gz/mdb'),('allowed_snd_types','mp3/midi/mid/wma/wav/ogg'),('allowed_img_types','ALL'),('allow_private_albums','1'),('allow_user_registration','0'),('allow_unlogged_access','1'),('allow_duplicate_emails_addr','0'),('caption_in_thumbview','1'),('views_in_thumbview','1'),('charset','utf-8'),('cookie_name','coppermine'),('cookie_path','/'),('debug_mode','1'),('debug_notice','0'),('default_dir_mode','0777'),('default_file_mode','0666'),('default_sort_order','na'),('ecards_more_pic_target','http://www.frog.za.net/photos/'),('home_target','http://www.frog.za.net/'),('custom_lnk_name',''),('custom_lnk_url',''),('enable_smilies','1'),('filter_bad_words','1'),('forbiden_fname_char','$/\\\\:*?&quot;&#39;&lt;&gt;|` &amp;'),('fullpath','albums/'),('gallery_admin_email','william.bell@frog.za.net'),('gallery_description',''),('gallery_name','Bell Family Album'),('im_options','-antialias'),('impath','/usr/bin/'),('jpeg_qual','80'),('keep_votes_time','30'),('lang','english'),('main_page_layout','breadcrumb/catlist/alblist/random,2/lastup,2'),('main_table_width','100%'),('make_intermediate','1'),('max_com_lines','5'),('max_com_size','128'),('max_com_wlength','38'),('max_img_desc_length','512'),('max_tabs','12'),('max_upl_size','1024'),('max_upl_width_height','2048'),('auto_resize','0'),('min_votes_for_rating','1'),('normal_pfx','normal_'),('offline','0'),('picture_table_width','600'),('picture_width','400'),('read_exif_data','0'),('reg_requires_valid_email','1'),('subcat_level','2'),('theme','classic'),('thumbcols','4'),('thumbrows','3'),('thumb_method','im'),('thumb_pfx','thumb_'),('thumb_width','100'),('userpics','userpics/'),('vanity_block','1'),('user_profile1_name','Location'),('user_profile2_name','Interests'),('user_profile3_name','Website'),('user_profile4_name','Occupation'),('user_profile5_name',''),('user_profile6_name','Biography'),('user_field1_name',''),('user_field2_name',''),('user_field3_name',''),('user_field4_name',''),('display_comment_count','1'),('show_private','0'),('first_level','1'),('display_film_strip','1'),('display_film_strip_filename','0'),('max_film_strip_items','5'),('thumb_use','any'),('read_iptc_data','0'),('reg_notify_admin_email','0'),('disable_comment_flood_protect','0'),('upl_notify_admin_email','0'),('display_uploader','0'),('display_filename','0'),('language_list','0'),('language_flags','0'),('theme_list','0'),('language_reset','1'),('theme_reset','1'),('allow_memberlist','0'),('display_faq','1'),('show_bbcode_help','1'),('log_ecards','0'),('email_comment_notification','1'),('enable_zipdownload','1'),('slideshow_interval','5000'),('log_mode','0'),('media_autostart','1'),('enable_encrypted_passwords','1'),('time_offset','2'),('ban_private_ip','0'),('smtp_host',''),('smtp_username','frogzane'),('smtp_password','wgbell'),('enable_plugins','1'),('enable_help','2'),('categories_alpha_sort','1'),('login_threshold','5'),('login_expiry','10'),('allow_email_change','0'),('clickable_keyword_search','1'),('users_can_edit_pics','0'),('show_which_exif','|0|0|0|0|0|0|0|0|1|0|1|1|0|0|0|0|0|0|0|0|0|0|0|1|0|0|0|1|0|0|0|1|1|0|0|0|0|1|0|0|0|1|0|0|1|1|0|0|0|0|0|1|0|1|1'),('link_pic_count','0'),('bridge_enable','0'),('language_fallback','1'),('vote_details','0'),('hit_details','0'),('browse_batch_add','1'),('custom_header_path',''),('custom_footer_path',''),('comments_sort_descending','0'),('report_post','0'),('comments_anon_pfx','Guest_'),('admin_activation','0');
/*!40000 ALTER TABLE `cpg_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpg_dict`
--

DROP TABLE IF EXISTS `cpg_dict`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cpg_dict` (
  `keyId` bigint(20) NOT NULL auto_increment,
  `keyword` varchar(60) NOT NULL default '',
  PRIMARY KEY  (`keyId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cpg_dict`
--

LOCK TABLES `cpg_dict` WRITE;
/*!40000 ALTER TABLE `cpg_dict` DISABLE KEYS */;
/*!40000 ALTER TABLE `cpg_dict` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpg_ecards`
--

DROP TABLE IF EXISTS `cpg_ecards`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cpg_ecards` (
  `eid` int(11) NOT NULL auto_increment,
  `sender_name` varchar(50) NOT NULL default '',
  `sender_email` text NOT NULL,
  `recipient_name` varchar(50) NOT NULL default '',
  `recipient_email` text NOT NULL,
  `link` text NOT NULL,
  `date` tinytext NOT NULL,
  `sender_ip` tinytext NOT NULL,
  PRIMARY KEY  (`eid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cpg_ecards`
--

LOCK TABLES `cpg_ecards` WRITE;
/*!40000 ALTER TABLE `cpg_ecards` DISABLE KEYS */;
/*!40000 ALTER TABLE `cpg_ecards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpg_exif`
--

DROP TABLE IF EXISTS `cpg_exif`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cpg_exif` (
  `filename` varchar(255) NOT NULL default '',
  `exifData` text NOT NULL,
  UNIQUE KEY `filename` (`filename`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cpg_exif`
--

LOCK TABLES `cpg_exif` WRITE;
/*!40000 ALTER TABLE `cpg_exif` DISABLE KEYS */;
/*!40000 ALTER TABLE `cpg_exif` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpg_favpics`
--

DROP TABLE IF EXISTS `cpg_favpics`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cpg_favpics` (
  `user_id` int(11) NOT NULL,
  `user_favpics` text NOT NULL,
  PRIMARY KEY  (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cpg_favpics`
--

LOCK TABLES `cpg_favpics` WRITE;
/*!40000 ALTER TABLE `cpg_favpics` DISABLE KEYS */;
/*!40000 ALTER TABLE `cpg_favpics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpg_filetypes`
--

DROP TABLE IF EXISTS `cpg_filetypes`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cpg_filetypes` (
  `extension` char(7) NOT NULL default '',
  `mime` char(30) default NULL,
  `content` char(15) default NULL,
  `player` varchar(5) default NULL,
  PRIMARY KEY  (`extension`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cpg_filetypes`
--

LOCK TABLES `cpg_filetypes` WRITE;
/*!40000 ALTER TABLE `cpg_filetypes` DISABLE KEYS */;
INSERT INTO `cpg_filetypes` (`extension`, `mime`, `content`, `player`) VALUES ('jpg','image/jpg','image',''),('jpeg','image/jpeg','image',''),('jpe','image/jpe','image',''),('gif','image/gif','image',''),('png','image/png','image',''),('bmp','image/bmp','image',''),('jpc','image/jpc','image',''),('jp2','image/jp2','image',''),('jpx','image/jpx','image',''),('jb2','image/jb2','image',''),('swc','image/swc','image','SWF'),('iff','image/iff','image',''),('asf','video/x-ms-asf','movie','WMP'),('asx','video/x-ms-asx','movie','WMP'),('mpg','video/mpeg','movie','WMP'),('mpeg','video/mpeg','movie','WMP'),('wmv','video/x-ms-wmv','movie','WMP'),('swf','application/x-shockwave-flash','movie','SWF'),('avi','video/avi','movie','WMP'),('mov','video/quicktime','movie','QT'),('mp3','audio/mpeg3','audio','WMP'),('midi','audio/midi','audio','WMP'),('mid','audio/midi','audio','WMP'),('wma','audio/x-ms-wma','audio','WMP'),('wav','audio/wav','audio','WMP'),('ogg','audio/ogg','audio',''),('psd','image/psd','image',''),('ram','audio/x-pn-realaudio','document','RMP'),('ra','audio/x-realaudio','document','RMP'),('rm','audio/x-realmedia','document','RMP'),('tiff','image/tiff','document',''),('tif','image/tif','document',''),('doc','application/msword','document',''),('txt','text/plain','document',''),('rtf','text/richtext','document',''),('pdf','application/pdf','document',''),('xls','application/excel','document',''),('pps','application/powerpoint','document',''),('ppt','application/powerpoint','document',''),('zip','application/zip','document',''),('rar','application/rar','document',''),('gz','application/gz','document',''),('mdb','application/msaccess','document','');
/*!40000 ALTER TABLE `cpg_filetypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpg_hit_stats`
--

DROP TABLE IF EXISTS `cpg_hit_stats`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cpg_hit_stats` (
  `sid` int(11) NOT NULL auto_increment,
  `pid` varchar(100) NOT NULL default '',
  `ip` varchar(20) NOT NULL default '',
  `search_phrase` varchar(255) NOT NULL default '',
  `sdate` bigint(20) NOT NULL default '0',
  `referer` text NOT NULL,
  `browser` varchar(255) NOT NULL default '',
  `os` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`sid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cpg_hit_stats`
--

LOCK TABLES `cpg_hit_stats` WRITE;
/*!40000 ALTER TABLE `cpg_hit_stats` DISABLE KEYS */;
/*!40000 ALTER TABLE `cpg_hit_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpg_pictures`
--

DROP TABLE IF EXISTS `cpg_pictures`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cpg_pictures` (
  `pid` int(11) NOT NULL auto_increment,
  `aid` int(11) NOT NULL default '0',
  `filepath` varchar(255) NOT NULL default '',
  `filename` varchar(255) NOT NULL default '',
  `filesize` int(11) NOT NULL default '0',
  `total_filesize` int(11) NOT NULL default '0',
  `pwidth` smallint(6) NOT NULL default '0',
  `pheight` smallint(6) NOT NULL default '0',
  `hits` int(10) NOT NULL default '0',
  `mtime` datetime NOT NULL default '0000-00-00 00:00:00',
  `ctime` int(11) NOT NULL default '0',
  `owner_id` int(11) NOT NULL default '0',
  `owner_name` varchar(40) NOT NULL default '',
  `pic_rating` int(11) NOT NULL default '0',
  `votes` int(11) NOT NULL default '0',
  `title` varchar(255) NOT NULL default '',
  `caption` text NOT NULL,
  `keywords` varchar(255) NOT NULL default '',
  `approved` enum('YES','NO') NOT NULL default 'NO',
  `galleryicon` int(11) NOT NULL default '0',
  `user1` varchar(255) NOT NULL default '',
  `user2` varchar(255) NOT NULL default '',
  `user3` varchar(255) NOT NULL default '',
  `user4` varchar(255) NOT NULL default '',
  `url_prefix` tinyint(4) NOT NULL default '0',
  `pic_raw_ip` tinytext,
  `pic_hdr_ip` tinytext,
  `lasthit_ip` tinytext,
  `position` int(11) NOT NULL default '0',
  PRIMARY KEY  (`pid`),
  KEY `pic_hits` (`hits`),
  KEY `pic_rate` (`pic_rating`),
  KEY `aid_approved` (`aid`,`approved`),
  KEY `pic_aid` (`aid`),
  KEY `owner_id` (`owner_id`),
  FULLTEXT KEY `search` (`title`,`caption`,`keywords`,`filename`)
) ENGINE=MyISAM AUTO_INCREMENT=159 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cpg_pictures`
--

LOCK TABLES `cpg_pictures` WRITE;
/*!40000 ALTER TABLE `cpg_pictures` DISABLE KEYS */;
INSERT INTO `cpg_pictures` (`pid`, `aid`, `filepath`, `filename`, `filesize`, `total_filesize`, `pwidth`, `pheight`, `hits`, `mtime`, `ctime`, `owner_id`, `owner_name`, `pic_rating`, `votes`, `title`, `caption`, `keywords`, `approved`, `galleryicon`, `user1`, `user2`, `user3`, `user4`, `url_prefix`, `pic_raw_ip`, `pic_hdr_ip`, `lasthit_ip`, `position`) VALUES (1,6,'userpics/','ejb78.JPG',53821,63945,300,225,15,'2008-10-19 20:06:01',1213974391,1,'frogzane',0,1,'Elijah  with smiles','','','YES',0,'','','','',0,'198.54.202.182','41.240.145.52','41.243.193.97',0),(2,1,'uploads/other/','camp003.JPG',29457,48137,300,200,9,'2008-10-19 19:52:06',1214227168,2,'Donette',0,1,'','','','YES',0,'','','','',0,'','','196.35.158.184',0),(3,1,'uploads/other/','camp001.JPG',36423,57598,200,300,11,'2008-10-25 15:15:35',1214227168,2,'Donette',0,1,'','','','YES',0,'','','','',0,'','','196.30.204.14',0),(4,1,'uploads/other/','camp002.JPG',44199,67966,300,200,11,'2008-10-25 15:15:48',1214227168,2,'Donette',0,1,'','','','YES',0,'','','','',0,'','','196.30.204.14',0),(5,1,'uploads/other/','camp004.JPG',41806,65082,200,300,18,'2008-10-19 20:36:54',1214227169,2,'Donette',0,1,'','','','YES',0,'','','','',0,'','','41.243.193.97',0),(6,1,'uploads/other/','camp005.JPG',42102,65433,300,200,18,'2008-10-25 15:15:22',1214227169,2,'Donette',0,1,'','','','YES',0,'','','','',0,'','','196.30.204.14',0),(7,1,'uploads/other/','camp006.JPG',45402,69023,300,200,14,'2008-10-19 19:53:28',1214227169,2,'Donette',0,1,'','','','YES',0,'','','','',0,'','','196.35.158.184',0),(8,1,'uploads/other/','hol001.JPG',27075,37950,300,225,13,'2008-10-19 19:53:49',1214227169,2,'Donette',0,1,'','','','YES',0,'','','','',0,'','','196.35.158.184',0),(9,1,'uploads/other/','hol002.JPG',27270,38284,300,225,12,'2008-10-19 19:54:11',1214227169,2,'Donette',0,1,'','','','YES',0,'','','','',0,'','','196.35.158.184',0),(10,1,'uploads/other/','hol003.JPG',42393,56833,300,225,11,'2008-10-19 19:54:28',1214227169,2,'Donette',0,1,'','','','YES',0,'','','','',0,'','','196.35.158.184',0),(11,1,'uploads/other/','hol004.JPG',29794,41270,300,225,16,'2008-10-19 19:54:46',1214227169,2,'Donette',0,1,'','','','YES',0,'','','','',0,'','','196.35.158.184',0),(12,1,'uploads/other/','jim001.JPG',32041,52320,300,200,18,'2008-10-19 19:55:10',1214227169,2,'Donette',0,1,'','','','YES',0,'','','','',0,'','','196.35.158.184',0),(13,1,'uploads/other/','jim002.JPG',32500,52052,200,300,13,'2008-10-19 19:55:43',1214227169,2,'Donette',0,1,'','','','YES',0,'','','','',0,'','','196.35.158.184',0),(14,1,'uploads/other/','jim003.JPG',43457,66829,300,200,17,'2008-10-19 19:54:58',1214227169,2,'Donette',0,1,'','','','YES',0,'','','','',0,'','','196.35.158.184',0),(15,1,'uploads/other/','jim004.JPG',43952,67235,300,200,16,'2008-10-19 19:55:21',1214227169,2,'Donette',0,1,'','','','YES',0,'','','','',0,'','','196.35.158.184',0),(16,1,'uploads/other/','jim005.JPG',43665,66848,300,200,16,'2008-10-19 19:56:08',1214227170,2,'Donette',0,1,'','','','YES',0,'','','','',0,'','','196.35.158.184',0),(17,4,'uploads/other/','fam.JPG',32797,53233,200,300,18,'2008-10-25 15:16:14',1214227230,2,'Donette',0,1,'Donette, William and Elijah ','Family photo taken at Jim Fouche Dec 2007','','YES',0,'','','','',0,'','','196.30.204.14',0),(18,4,'uploads/other/','fam001.JPG',18309,27938,300,196,16,'2008-10-25 15:16:22',1214227230,2,'Donette',0,1,'Siblings','Gerry Roelofsz, Jacky Smith, Donette Bell and Raymond Roelofsz','','YES',0,'','','','',0,'','','196.30.204.14',0),(19,4,'uploads/other/','fam003.JPG',20637,30991,300,187,18,'2008-10-25 15:16:48',1214227231,2,'Donette',0,1,'Dad and Siblings','Gerry Roelofsz, Donette Bell, Lenard Roelofsz, Jacky Smith and Raymond Roleofsz ','','YES',0,'','','','',0,'','','196.30.204.14',0),(20,4,'uploads/other/','fam002.JPG',28639,41858,300,215,19,'2008-10-25 15:16:36',1214227231,2,'Donette',0,1,'All the kids','Photo taken Dec 2007','','YES',0,'','','','',0,'','','196.30.204.14',0),(21,7,'uploads/other/','rtir1.JPG',23643,34595,300,225,17,'2008-10-19 20:16:39',1214227231,2,'Donette',0,1,'RTIR 2008','William skippered Elijah&#39;s Hobie in the Sanlam Round the Island Race 2008','','YES',0,'','','','',0,'','','196.35.158.184',0),(22,4,'uploads/other/','fam004.JPG',19092,28425,300,225,18,'2008-10-25 15:16:58',1214227231,2,'Donette',0,1,'Gerry and Aiden','Dad and baba ','','YES',0,'','','','',0,'','','196.30.204.14',0),(23,7,'uploads/other/','shrek1.jpg',94712,113332,400,267,21,'2008-10-19 20:16:57',1214227231,2,'Donette',0,1,'Shreks ','Aiden Roelofsz and Elijah Bell 18 May  2008...Present from Gerry and Sue Roelofsz','','YES',0,'','','','',0,'','','196.35.158.184',0),(24,7,'uploads/other/','shrek2.jpg',91992,110065,400,267,22,'2008-10-19 20:15:17',1214227232,2,'Donette',0,1,'Shreks again','','','YES',0,'','','','',0,'','','196.35.158.184',0),(25,7,'uploads/other/','shrek3.jpg',91642,109795,400,267,15,'2008-10-19 20:17:17',1214227232,2,'Donette',0,1,'Shreks another time ','','','YES',0,'','','','',0,'','','196.35.158.184',0),(26,7,'uploads/other/','shrek4.jpg',80255,97843,400,267,18,'2008-10-19 20:17:33',1214227232,2,'Donette',0,1,'Happy Shreks ','','','YES',0,'','','','',0,'','','196.35.158.184',0),(27,8,'uploads/other/','train1.JPG',68239,78770,300,225,17,'2008-10-19 20:24:18',1214227232,2,'Donette',0,1,'The train that never stops','Thomas the train is becoming the &quot;i know i can&quot; train which never stops running ','','YES',0,'','','','',0,'','','198.54.202.166',101),(28,6,'uploads/growing/','ejb2.jpg',22512,40126,200,150,13,'2008-10-19 20:06:18',1214228093,2,'Donette',0,1,'First real cuddle with Daddy','','','YES',0,'','','','',0,'','','41.243.193.97',0),(29,6,'uploads/growing/','ejb4.jpg',22068,39475,200,150,11,'2008-10-19 20:06:35',1214228093,2,'Donette',0,1,'Hands','','','YES',0,'','','','',0,'','','41.243.193.97',0),(30,6,'uploads/growing/','ejb5.jpg',22504,39857,200,150,11,'2008-10-19 20:06:52',1214228093,2,'Donette',0,1,'Our little Boy','','','YES',0,'','','','',0,'','','41.243.193.97',0),(31,6,'uploads/growing/','ejb7.jpg',26380,46864,200,150,14,'2008-10-19 20:07:09',1214228093,2,'Donette',0,1,'Crawling time','','','YES',0,'','','','',0,'','','41.243.193.97',0),(32,6,'uploads/growing/','ejb8.jpg',24100,43037,133,200,17,'2008-10-19 20:03:39',1214228093,2,'Donette',0,1,'Dedication ','','','YES',0,'','','','',0,'','','198.54.202.166',0),(33,6,'uploads/growing/','ejb9.jpg',29884,52204,200,133,15,'2008-10-19 20:07:29',1214228094,2,'Donette',0,1,'Mommy  Daddy and Me','','','YES',0,'','','','',0,'','','41.243.193.97',0),(34,6,'uploads/growing/','ejb10.jpg',10263,17085,200,113,21,'2008-10-19 20:07:46',1214228094,2,'Donette',0,1,'2 hours old','Elijah Bell and Donette Bell,  First cuddle with Mommy','','YES',0,'','','','',0,'','','41.243.193.97',0),(35,6,'uploads/growing/','ejb11.jpg',25171,45173,200,133,13,'2008-10-19 20:08:04',1214228094,2,'Donette',0,1,'Leopard crawling ','','','YES',0,'','','','',0,'','','41.243.193.97',0),(36,6,'uploads/growing/','ejb12.JPG',26521,46259,200,133,16,'2008-10-19 20:08:15',1214228094,2,'Donette',0,1,'Elijah on his boat','Elijah (almost 9 months)  at RTIR 2007 on his Hobie cat ','','YES',0,'','','','',0,'','','198.54.202.166',0),(37,6,'uploads/growing/','ejb13.jpg',24352,42970,200,150,21,'2008-10-19 20:08:27',1214228094,2,'Donette',0,1,'Elijah with Oupa and Ouma Bell','First day home ','','YES',0,'','','','',0,'','','198.54.202.166',0),(38,6,'uploads/growing/','ejb14.jpg',20069,35593,200,150,16,'2008-10-19 20:08:39',1214228094,2,'Donette',0,1,'Nanny and Elijah ','','','YES',0,'','','','',0,'','','198.54.202.166',0),(39,6,'uploads/growing/','ejb15.jpg',23474,41731,200,150,14,'2008-10-19 20:08:22',1214228094,2,'Donette',0,1,'Elijah with Oupa and Granny Roelofsz ','','','YES',0,'','','','',0,'','','198.54.202.166',0),(40,6,'uploads/growing/','ejb16.jpg',22913,40751,200,150,13,'2008-10-19 20:08:33',1214228094,2,'Donette',0,1,'Big Yawn ','','','YES',0,'','','','',0,'','','198.54.202.166',0),(41,6,'uploads/growing/','ejb17.jpg',27214,48065,200,150,14,'2008-10-19 20:08:48',1214228095,2,'Donette',0,1,'Best smile ','','','YES',0,'','','','',0,'','','198.54.202.166',0),(42,6,'uploads/growing/','ejb18.jpg',27408,48393,200,150,14,'2008-10-19 20:08:53',1214228095,2,'Donette',0,1,'First Picnic','First picnic at Mimosa in Parys - Free State ','','YES',0,'','','','',0,'','','198.54.202.166',0),(43,6,'uploads/growing/','ejb19.jpg',32582,56673,150,200,13,'2008-10-19 20:08:56',1214228095,2,'Donette',0,1,'Picnic walk with Daddy ','','','YES',0,'','','','',0,'','','198.54.202.166',0),(44,6,'uploads/growing/','ejb20.jpg',25886,45867,200,150,13,'2008-10-19 20:09:00',1214228095,2,'Donette',0,1,'Toes! ','','','YES',0,'','','','',0,'','','198.54.202.166',0),(45,6,'uploads/growing/','ejb21.JPG',18203,32936,200,150,19,'2008-10-19 20:09:02',1214228095,2,'Donette',5000,2,'Elijah at home in the pool ','','','YES',0,'','','','',0,'','','198.54.202.166',0),(46,6,'uploads/growing/','ejb22.JPG',25490,45246,200,150,16,'2008-10-19 20:32:10',1214228095,2,'Donette',0,1,'Daddy and Elijah at ','','','YES',0,'','','','',0,'','','196.35.158.184',0),(47,6,'uploads/growing/','ejb23.JPG',18045,32344,200,150,10,'2008-10-19 20:31:23',1214228095,2,'Donette',0,1,'Bath time with Daddy','','','YES',0,'','','','',0,'','','196.35.158.184',0),(48,6,'uploads/growing/','ejb24.JPG',33092,53939,200,267,13,'2008-10-19 20:32:32',1214228095,2,'Donette',0,1,'Daddy and Elijah ','','','YES',0,'','','','',0,'','','196.35.158.184',0),(49,6,'uploads/growing/','ejb25.JPG',26392,46545,150,200,10,'2008-10-19 20:31:41',1214228095,2,'Donette',0,1,'Outside in the Garden ','','','YES',0,'','','','',0,'','','196.35.158.184',0),(50,6,'uploads/growing/','ejb27.JPG',25449,44803,150,200,11,'2008-10-19 20:32:52',1214228095,2,'Donette',0,1,'Outside in the Garden ','','','YES',0,'','','','',0,'','','196.35.158.184',0),(51,6,'uploads/growing/','ejb28.JPG',25376,44646,200,150,11,'2008-10-19 20:34:47',1214228095,2,'Donette',0,1,'Fun with Daddy at Christmas','','','YES',0,'','','','',0,'','','196.35.158.184',0),(52,6,'uploads/growing/','ejb29.JPG',27422,48280,150,200,21,'2008-10-19 20:03:12',1214228096,2,'Donette',0,1,'First Christmas on the Ride on from Oupa Roelofsz ','','','YES',0,'','','','',0,'','','198.54.202.166',0),(53,6,'uploads/growing/','ejb30.JPG',21651,38429,200,150,11,'2008-10-19 20:35:05',1214228096,2,'Donette',0,1,'Chocolate is good ','','','YES',0,'','','','',0,'','','41.243.193.97',0),(54,6,'uploads/growing/','ejb32.jpg',9067,14777,200,113,21,'2008-10-19 20:03:03',1214228096,2,'Donette',0,1,'First Photo ','','','YES',0,'','','','',0,'','','198.54.202.166',0),(55,6,'uploads/growing/','ejb33.jpg',10544,17052,200,113,16,'2008-10-19 20:03:42',1214228096,2,'Donette',0,1,'Elijah with Oupa and Ouma Roelofsz ','','','YES',0,'','','','',0,'','','198.54.202.166',0),(56,6,'uploads/growing/','ejb34.JPG',26581,46459,150,200,14,'2008-10-19 20:36:09',1214228096,2,'Donette',0,1,'Daddy and Elijah on the Beach at Fishhoek Capetown ','','','YES',0,'','','','',0,'','','41.243.193.97',0),(57,6,'uploads/growing/','ejb35.JPG',19824,35383,200,150,11,'2008-10-19 20:36:30',1214228096,2,'Donette',0,1,'Play time ','At Jungle rumble ','','YES',0,'','','','',0,'','','41.243.193.97',0),(58,6,'uploads/growing/','ejb36.JPG',27872,47439,250,188,10,'2008-10-19 20:09:11',1214228096,2,'Donette',0,1,'Tunnel Fun','','','YES',0,'','','','',0,'','','198.54.202.166',0),(59,6,'uploads/growing/','ejb37.JPG',34034,55104,300,200,16,'2008-10-19 20:09:14',1214228096,2,'Donette',0,1,'Mommy and Elijah at Ducks inn in Henley on Klip','','','YES',0,'','','','',0,'','','198.54.202.166',0),(60,6,'uploads/growing/','ejb38.JPG',28427,50342,200,133,28,'2008-10-19 20:09:20',1214228096,2,'Donette',0,1,'Waiting for Daddy to finish Argus','2007 ','','YES',0,'','','','',0,'','','198.54.202.166',0),(61,6,'uploads/growing/','ejb39.JPG',24006,43244,133,200,15,'2008-10-19 20:09:22',1214228096,2,'Donette',0,1,'Driving Uncle Dylan&#39;s car','','','YES',0,'','','','',0,'','','198.54.202.166',0),(62,6,'uploads/growing/','ejb40.JPG',30228,51275,250,167,10,'2008-10-19 20:09:26',1214228096,2,'Donette',0,1,'Beach fun in CT','','','YES',0,'','','','',0,'','','198.54.202.166',0),(63,6,'uploads/growing/','ejb41.JPG',33595,55663,250,167,10,'2008-10-19 20:44:22',1214228096,2,'Donette',0,1,'Beach at Gordan&#39;s Bay CT','','','YES',0,'','','','',0,'','','196.35.158.184',0),(64,6,'uploads/growing/','ejb42.JPG',32704,54302,167,250,14,'2008-10-19 20:40:46',1214228097,2,'Donette',0,1,'Table Mountain ','','','YES',0,'','','','',0,'','','196.35.158.184',0),(65,6,'uploads/growing/','ejb43.JPG',26655,45054,167,250,14,'2008-10-19 20:40:14',1214228097,2,'Donette',0,1,'Handsome Dude ','','','YES',0,'','','','',0,'','','196.35.158.184',0),(66,6,'uploads/growing/','ejb44.JPG',39130,62051,188,250,10,'2008-10-19 20:40:57',1214228097,2,'Donette',0,1,'Hose fun?','','','YES',0,'','','','',0,'','','196.35.158.184',0),(67,6,'uploads/growing/','ejb45.JPG',24686,37591,250,240,14,'2008-10-19 20:40:26',1214228097,2,'Donette',0,1,'Outdoor Adventurer','','','YES',0,'','','','',0,'','','196.35.158.184',0),(68,6,'uploads/growing/','ejb46.JPG',21614,32907,186,250,14,'2008-10-19 20:41:14',1214228097,2,'Donette',0,1,'Explaining things to mommy','','','YES',0,'','','','',0,'','','196.35.158.184',0),(69,6,'uploads/growing/','ejb47.JPG',19396,29920,187,250,9,'2008-10-19 20:09:37',1214228097,2,'Donette',0,1,'Cute ','','','YES',0,'','','','',0,'','','198.54.202.166',0),(70,6,'uploads/growing/','ejb48.JPG',23180,35664,209,250,15,'2008-10-19 20:09:40',1214228097,2,'Donette',0,1,'Window washer ','','','YES',0,'','','','',0,'','','198.54.202.166',0),(71,6,'uploads/growing/','ejb49.JPG',35767,50914,333,250,14,'2008-10-19 20:09:42',1214228097,2,'Donette',0,1,'Swing is a wonderful thing','','','YES',0,'','','','',0,'','','198.54.202.166',0),(72,6,'uploads/growing/','ejb50.JPG',22262,33339,250,188,11,'2008-10-19 20:59:43',1214228097,2,'Donette',0,1,'The places he gets into ','','','YES',0,'','','','',0,'','','41.243.193.97',0),(73,6,'uploads/growing/','ejb51.JPEG',15556,18115,201,300,10,'2008-10-19 20:59:26',1214228097,2,'Donette',0,1,'Mardo&#39;s Comp 2007','','','YES',0,'','','','',0,'','','41.243.193.97',0),(74,6,'uploads/growing/','ejb52.JPEG',14278,16778,197,300,9,'2008-10-19 20:58:10',1214228097,2,'Donette',0,1,'Mardo&#39;s Comp 2007 again','','','YES',0,'','','','',0,'','','196.35.158.184',0),(75,6,'uploads/growing/','ejb53.JPG',31411,44686,300,225,11,'2008-10-19 20:57:58',1214228097,2,'Donette',0,1,'Beach fun at Suncity ','','','YES',0,'','','','',0,'','','196.35.158.184',0),(76,6,'uploads/growing/','ejb54.JPG',35958,50152,300,225,11,'2008-10-19 20:57:44',1214228098,2,'Donette',0,1,'Peek-a-boo','','','YES',0,'','','','',0,'','','196.35.158.184',0),(77,6,'uploads/growing/','ejb55.jpg',23382,33532,300,225,12,'2008-10-19 20:57:24',1214228098,2,'Donette',0,1,'Swimming Lessons Dec 2007','','','YES',0,'','','','',0,'','','196.35.158.184',0),(78,6,'uploads/growing/','ejb56.jpg',20326,29786,300,225,16,'2008-10-19 20:29:02',1214228098,2,'Donette',0,1,'Swimming Lessons Dec 2007 with Ouma ','','','YES',0,'','','','',0,'','','196.35.158.184',0),(79,6,'uploads/growing/','ejb57.jpg',20374,29983,300,225,11,'2008-10-19 20:27:52',1214228098,2,'Donette',0,1,'Piano child ','','','YES',0,'','','','',0,'','','196.35.158.184',0),(80,6,'uploads/growing/','ejb58.jpg',22634,32920,300,225,14,'2008-10-19 20:29:40',1214228098,2,'Donette',0,1,'Sand Box','','','YES',0,'','','','',0,'','','196.35.158.184',0),(81,6,'uploads/growing/','ejb59.jpg',21515,32162,300,225,11,'2008-10-19 20:28:24',1214228098,2,'Donette',0,1,'Defintiely a boy ','','','YES',0,'','','','',0,'','','196.35.158.184',0),(82,6,'uploads/growing/','ejb60.jpg',26988,38724,300,225,23,'2008-10-22 22:02:23',1214228098,2,'Donette',4667,3,'Loving Daddy','','','YES',0,'','','','',0,'','','198.54.202.182',0),(83,6,'uploads/growing/','ejb61.jpg',31241,42595,300,225,12,'2008-10-19 20:56:43',1214228098,2,'Donette',0,1,'Ice-Cream!','','','YES',0,'','','','',0,'','','196.35.158.184',0),(84,6,'uploads/growing/','ejb62.jpg',25182,35761,300,225,17,'2008-10-22 22:02:47',1214228098,2,'Donette',0,1,'Box Fun','','','YES',0,'','','','',0,'','','198.54.202.182',0),(85,6,'uploads/growing/','ejb63.jpg',23731,33837,300,225,15,'2008-10-19 20:56:28',1214228098,2,'Donette',0,1,'I can Fit!','','','YES',0,'','','','',0,'','','196.35.158.184',0),(86,6,'uploads/growing/','ejb64.JPG',53359,63284,200,300,15,'2008-10-19 20:56:12',1214228098,2,'Donette',0,1,'Oupa and me ','','','YES',0,'','','','',0,'','','196.35.158.184',0),(87,6,'uploads/growing/','ejb65.JPG',89292,103133,300,308,15,'2008-10-19 20:55:50',1214228099,2,'Donette',0,1,'Oupa, Me and my Cousins ','','','YES',0,'','','','',0,'','','196.35.158.184',0),(88,6,'uploads/growing/','ejb66.JPG',22873,34172,188,300,17,'2008-10-19 20:10:53',1214228099,2,'Donette',0,1,'Fun at the Vaal Dam ','','','YES',0,'','','','',0,'','','196.35.158.184',0),(89,6,'uploads/growing/','ejb67.JPG',28989,41528,300,225,15,'2008-10-19 20:43:39',1214228099,2,'Donette',0,1,'Daddy and me 2008','','','YES',0,'','','','',0,'','','196.35.158.184',0),(90,6,'uploads/growing/','ejb68.JPG',21529,31770,300,225,15,'2008-10-19 20:43:16',1214228099,2,'Donette',0,1,'Biker ','','','YES',0,'','','','',0,'','','196.35.158.184',0),(91,6,'uploads/growing/','ejb69.JPG',26781,38427,300,225,16,'2008-10-19 20:43:50',1214228099,2,'Donette',0,1,'Daddy and me at Drakensburg sun','','','YES',0,'','','','',0,'','','196.35.158.184',0),(92,6,'uploads/growing/','ejb70.JPG',29654,42140,300,225,16,'2008-10-19 20:43:27',1214228099,2,'Donette',0,1,'Finger painting','','','YES',0,'','','','',0,'','','196.35.158.184',0),(93,6,'uploads/growing/','ejb71.JPG',28700,41370,300,225,16,'2008-10-19 20:44:03',1214228099,2,'Donette',0,1,'My Boat','','','YES',0,'','','','',0,'','','196.35.158.184',0),(94,6,'uploads/growing/','ejb72.JPG',28194,39657,300,225,19,'2008-10-19 20:10:58',1214228099,2,'Donette',0,1,'Drakensburg 2008','','','YES',0,'','','','',0,'','','196.35.158.184',0),(95,6,'uploads/growing/','ejb73.JPG',21611,32196,300,225,16,'2008-10-19 20:55:17',1214228099,2,'Donette',0,1,'Jungle Gym time ','','','YES',0,'','','','',0,'','','196.35.158.184',0),(96,6,'uploads/growing/','ejb74.JPG',27258,38936,300,225,19,'2008-10-19 20:55:01',1214228099,2,'Donette',0,1,'Jungle Gym time with Dad','','','YES',0,'','','','',0,'','','196.35.158.184',0),(97,6,'uploads/growing/','ejb75.JPG',32729,45610,300,225,16,'2008-10-19 20:42:04',1214228099,2,'Donette',0,1,'My Truck ','','','YES',0,'','','','',0,'','','196.35.158.184',0),(98,6,'uploads/growing/','ejb76.JPG',75649,87661,300,225,19,'2008-10-19 20:41:39',1214228099,2,'Donette',0,1,'Trucks are fun','','','YES',0,'','','','',0,'','','196.35.158.184',0),(99,6,'uploads/growing/','ejb77.JPG',54101,64211,300,225,17,'2008-10-19 20:42:16',1214228100,2,'Donette',0,1,'I am Handsome','','','YES',0,'','','','',0,'','','196.35.158.184',0),(100,6,'uploads/growing/','ejb78.JPG',53821,63945,300,225,18,'2008-10-19 20:41:51',1214228100,2,'Donette',0,1,'Too cute','','','YES',0,'','','','',0,'','','196.35.158.184',0),(101,1,'uploads/growing/','hotel2.JPG',36196,49978,300,225,22,'2008-10-19 20:54:26',1214228100,2,'Donette',0,1,'Suncity ','','','YES',0,'','','','',0,'','','41.243.193.97',0),(102,6,'uploads/growing/','IMG_2533.JPG',51068,69765,250,167,17,'2008-10-19 20:42:26',1214228100,2,'Donette',0,1,'Me and Bob the Gorilla ','','','YES',0,'','','','',0,'','','196.35.158.184',0),(103,6,'uploads/growing/','IMG_2547.JPG',49815,68237,250,167,18,'2008-10-19 20:54:05',1214228100,2,'Donette',0,1,'Tired? ','','','YES',0,'','','','',0,'','','41.243.193.97',0),(104,6,'uploads/growing/','IMG_2615.JPG',53057,72607,167,250,17,'2008-10-19 20:53:48',1214228100,2,'Donette',0,1,'Looking good at 13 1/2 months','','','YES',0,'','','','',0,'','','41.243.193.97',0),(105,6,'uploads/growing/','IMG_3502.JPG',51124,70891,167,250,19,'2008-10-19 20:53:31',1214228100,2,'Donette',0,1,'Birthday party May 2007','','','YES',0,'','','','',0,'','','41.243.193.97',0),(106,6,'uploads/growing/','IMG_3538.JPG',52292,71778,250,167,21,'2008-10-19 20:53:14',1214228100,2,'Donette',0,1,'My Cake for my 1st Birthday party','','','YES',0,'','','','',0,'','','41.243.193.97',0),(107,6,'uploads/growing/','picasso.JPG',28087,33387,250,188,17,'2008-10-19 20:27:18',1214228100,2,'Donette',0,1,'Picasso?','','','YES',0,'','','','',0,'','','196.35.158.184',0),(108,1,'uploads/growing/','staircase.JPG',35517,48638,300,225,21,'2008-10-19 20:52:52',1214228100,2,'Donette',0,1,'The Golden Staircase at Suncity','','','YES',0,'','','','',0,'','','41.243.193.97',0),(109,4,'uploads/growing/','sueandaiden.JPG',16345,26856,250,188,22,'2008-10-19 19:59:41',1214228101,2,'Donette',0,1,'Sue and Aiden','','','YES',0,'','','','',0,'','','196.35.158.184',0),(110,8,'uploads/','cake1.JPG',89153,123766,400,268,24,'2008-10-19 20:24:10',1214229507,2,'Donette',0,1,'Blowing the candles','','','YES',0,'','','','',0,'','','198.54.202.166',102),(111,8,'uploads/','cake2.JPG',81035,113597,400,234,23,'2008-10-19 20:24:03',1214229507,2,'Donette',0,1,'My Cake ','','','YES',0,'','','','',0,'','','198.54.202.166',103),(112,8,'uploads/','present.jpg',90840,103421,400,312,25,'2008-10-19 20:23:53',1214229507,2,'Donette',0,1,'Opening my gift ','from Mommy and Daddy','','YES',0,'','','','',0,'','','198.54.202.166',104),(113,8,'uploads/','shrek.jpg',66142,77168,243,400,31,'2008-10-19 20:22:53',1214229507,2,'Donette',0,1,'Shrek','Jacket from Gerry, Sue and Aiden','','YES',0,'','','','',0,'','','198.54.202.166',105),(114,8,'uploads/','tooldesk.JPG',64215,99370,257,400,23,'2008-10-19 20:23:44',1214229507,2,'Donette',0,1,'Tooldesk','from Oupa Roelofsz','','YES',0,'','','','',0,'','','198.54.202.166',106),(115,8,'uploads/','train.JPG',88274,101258,400,300,31,'2008-10-19 20:22:58',1214229508,2,'Donette',0,1,'Playing with the Train','','','YES',0,'','','','',0,'','','198.54.202.166',107),(116,9,'userpics/','IMG_0909.JPG',63874,76031,300,225,33,'2008-10-19 19:45:32',1214243251,1,'frogzane',0,1,'Transport Poster ','June 2008','','YES',0,'','','','',0,'198.54.202.182','41.240.144.199','196.35.158.184',0),(117,9,'userpics/','IMG_0906.JPG',54942,65696,300,225,56,'2008-10-19 19:43:58',1214243268,1,'frogzane',0,1,'Car Mobile','June 2008 - Transport theme','','YES',0,'','','','',0,'198.54.202.182','41.240.144.199','196.35.158.184',0),(118,7,'userpics/','IMG_0903.JPG',59750,70485,300,225,32,'2008-10-19 20:42:54',1214243331,1,'frogzane',0,1,'The Techies','Daddy and Elijah both using their electronic screwdrivers ','','YES',0,'','','','',0,'198.54.202.182','41.240.144.199','196.35.158.184',0),(119,7,'userpics/','IMG_0901.JPG',61566,72595,300,225,40,'2008-10-19 20:42:53',1214243345,1,'frogzane',5000,2,'Daddy riding Elijah&#39;s Bike','','','YES',0,'','','','',0,'198.54.202.182','41.240.144.199','196.35.158.184',0),(120,7,'userpics/','IMG_0918.JPG',103426,116215,400,300,27,'2008-10-19 20:42:51',1214389045,1,'frogzane',0,1,'Karen and Alex','Stonehaven 25/6/2008','','YES',0,'','','','',0,'198.54.202.182','41.240.166.105','196.35.158.184',0),(121,7,'userpics/','IMG_0913.JPG',130691,145387,400,300,35,'2008-10-19 20:42:50',1214389070,1,'frogzane',0,1,'Abbie and Tristan','Stonehaven 25/06/2008','','YES',0,'','','','',0,'198.54.202.182','41.240.166.105','196.35.158.184',0),(122,8,'userpics/','IMG_0912.JPG',122376,135117,400,300,27,'2008-10-19 20:42:49',1214389113,1,'frogzane',0,1,'Elijah ','Gardening Project 24/06/2008','','YES',0,'','','','',0,'198.54.202.182','41.240.166.105','196.35.158.184',109),(123,8,'userpics/','IMG_0910.JPG',132307,145242,400,300,35,'2008-10-19 20:42:48',1214389142,1,'frogzane',0,1,'Elijah','Gardening Project 2008/06/25','','YES',0,'','','','',0,'198.54.202.182','41.240.166.105','196.35.158.184',108),(124,7,'userpics/','IMG_0924.JPG',112256,125631,400,300,30,'2008-10-19 20:42:47',1214389278,1,'frogzane',0,1,'Karen and Alex','Stonehaven 25/06/2008','','YES',0,'','','','',0,'198.54.202.182','41.240.166.105','196.35.158.184',0),(125,7,'userpics/','IMG_0922.JPG',96023,107009,400,300,29,'2008-10-19 20:42:45',1214389304,1,'frogzane',0,1,'Elijah  Bell','Stonehaven 25/06/2008','','YES',0,'','','','',0,'198.54.202.182','41.240.166.105','196.35.158.184',0),(126,7,'userpics/','IMG_0918~0.JPG',103426,116215,400,300,40,'2008-10-19 20:42:44',1214389331,1,'frogzane',3000,2,'Karen and Alex','Stonehaven 25/06/2008','','YES',0,'','','','',0,'198.54.202.182','41.240.166.105','196.35.158.184',0),(127,7,'userpics/','IMG_0915.JPG',90046,102489,400,300,39,'2008-10-19 20:51:14',1214389349,1,'frogzane',0,1,'Abbie and Tristan','Stonehaven 25/06/2008','','YES',0,'','','','',0,'198.54.202.182','41.240.166.105','41.243.193.97',0),(128,8,'userpics/','IMG_0929.JPG',138597,171910,500,375,63,'2008-10-19 20:42:41',1214890621,1,'frogzane',5000,2,'Elijah ','Elijah decided Mom hadn&#39;t used enough cream','','YES',0,'','','','',0,'198.54.202.182','41.240.176.208','196.35.158.184',110),(129,9,'userpics/','IMG_0933.JPG',73794,85902,300,400,35,'2008-10-19 20:42:40',1215002136,1,'frogzane',0,1,'Playgroup Activity  2008-07-02','Made Photo frame from pasta, wood glue, gold spray paint and added magnet strip at the back','','YES',0,'','','','',0,'198.54.202.182','41.240.190.71','196.35.158.184',0),(130,8,'userpics/','IMG_1070.JPG',76831,106337,500,375,24,'2008-10-19 20:24:29',1216037977,2,'Donette',0,1,'Elijah 2 years, ','','Elijah','YES',0,'','','','',0,'198.54.202.182','41.240.188.219','198.54.202.166',100),(131,4,'userpics/','IMG_1050.JPG',86362,121247,500,375,28,'2008-10-19 19:58:23',1216038007,2,'Donette',0,1,'Elijah and Daddy','','','YES',0,'','','','',0,'198.54.202.182','41.240.188.219','196.35.158.184',0),(132,7,'userpics/','IMG_1035.JPG',161263,212964,450,600,47,'2008-10-19 20:16:08',1216038039,2,'Donette',0,2,'Elijah in a basket','Wish it was always this easy to keep him &quot;contained&quot;','','YES',0,'','','','',0,'198.54.202.182','41.240.188.219','196.35.158.184',0),(133,10,'userpics/','babyBell1.jpeg',127926,144865,600,456,27,'2008-10-25 15:14:28',1216383571,2,'Donette',0,1,'baby 5.5mm','Fetal age approx 4w3d','','YES',0,'','','','',0,'198.54.202.182','41.240.190.115','196.30.204.14',0),(134,10,'userpics/','babyBell.jpeg',133380,156222,600,455,55,'2008-10-25 15:13:51',1216383630,2,'Donette',5000,2,'Sonar done at 6weeks pregnant','Fetal age 4w 3d\r\nApprox due date 24/03/2009','','YES',0,'','','','',0,'198.54.202.182','41.240.190.115','196.30.204.14',0),(135,4,'userpics/','IMG_1057p.JPG',67064,107563,640,483,37,'2008-10-19 19:58:30',1217440273,3,'william',5000,2,'','','','YES',0,'','','','',0,'198.54.202.182','41.240.141.180','196.35.158.184',0),(136,8,'userpics/','IMG_1258.JPG',116511,147338,640,480,33,'2008-10-19 20:24:37',1218100796,2,'Donette',0,1,'Haircut by Dad','','','YES',0,'','','','',0,'198.54.202.182','41.240.152.20','198.54.202.166',0),(137,8,'userpics/','IMG_1235.JPG',238869,305699,640,480,45,'2008-10-19 20:23:06',1218100816,2,'Donette',0,1,'Things I do when I visit Oupa and Ouma Bell','','','YES',0,'','','','',0,'198.54.202.182','41.240.152.20','198.54.202.166',0),(138,8,'userpics/','IMG_1199.JPG',188738,244597,640,480,40,'2008-10-19 20:22:37',1218100844,2,'Donette',0,1,'Missiles to throw at suspecting Parents','','','YES',0,'','','','',0,'198.54.202.182','41.240.152.20','198.54.202.166',0),(139,8,'userpics/','IMG_1292.JPG',187419,235507,640,480,42,'2008-10-19 20:33:38',1218984070,2,'Donette',0,1,'Elijah in my new hat','Hat brought from New Zealand by Uncle Kurt','hat Elijah','YES',0,'','','','',0,'198.54.202.182','41.240.177.63','196.35.158.184',0),(140,9,'userpics/','IMG_1300.JPG',184366,236286,600,450,50,'2008-10-19 19:44:01',1220274795,2,'Donette',0,1,'Brown Bear','Felt board story that goes with story called Brown bear, brown bear what do u see?\r\nImages were taken off DLTK website.\r\n\r\n','homeschool, animals, brown bear, felt board','YES',0,'','','','',0,'198.54.202.182','41.240.148.93','196.35.158.184',0),(141,8,'userpics/','IMG_1272.JPG',133675,173350,640,480,44,'2008-10-19 20:22:25',1220508746,2,'Donette',0,1,'What do u mean I am dirty?','','Elijah, playtime, 2, two, dirt','YES',0,'','','','',0,'198.54.202.182','41.240.170.86','198.54.202.166',0),(142,8,'userpics/','IMG_1271.JPG',137351,177074,640,480,51,'2008-10-19 20:22:16',1220508800,2,'Donette',0,1,'Caught in the act!','So that is how he get&#39;s those things off! He broke Daddy&#39;s reading glasses that were on top there. ','','YES',0,'','','','',0,'198.54.202.182','41.240.170.86','198.54.202.166',0),(143,8,'userpics/','IMG_1268.JPG',185241,236126,480,640,35,'2008-10-19 20:23:11',1220508825,2,'Donette',0,1,'All ready to Ride!','','Elijah, Bike, toy','YES',0,'','','','',0,'198.54.202.182','41.240.170.86','198.54.202.166',0),(144,8,'userpics/','IMG_1263.JPG',152072,197360,480,640,36,'2008-10-19 20:45:38',1220508871,2,'Donette',0,1,'Cute in the morning, cute in the evening','My Favorite place in the kitchen...waiting for my bottle or breakfast','Elijah, kitchen','YES',0,'','','','',0,'198.54.202.182','41.240.170.86','196.35.158.184',0),(145,8,'userpics/','IMG_1295.JPG',182872,230786,640,480,45,'2008-10-19 20:23:10',1220509267,2,'Donette',0,1,'Elijah&#39;s favourite game','We dont put here as punishment...he always finds the box no matter where i hide it! ','','YES',0,'','','','',0,'198.54.202.182','41.240.170.86','198.54.202.166',0),(146,9,'userpics/','IMG_1366.JPG',168108,210579,480,640,36,'2008-10-19 19:45:18',1222931321,2,'Donette',0,1,'Grounded car is still fun','We made this car...mommy painted the front and Elijah painted the side and back','car, homeschool, activities','YES',0,'','','','',0,'198.54.202.182','41.240.171.237','196.35.158.184',0),(147,9,'userpics/','IMG_1353.JPG',141167,190464,480,556,42,'2008-10-19 20:30:33',1222931371,2,'Donette',0,1,'Car is up and running','Elijah having fun','','YES',0,'','','','',0,'198.54.202.182','41.240.171.237','196.35.158.184',0),(148,9,'userpics/','IMG_1351.JPG',160378,211447,640,480,40,'2008-10-19 20:30:31',1222931387,2,'Donette',0,1,'Painting Car','','','YES',0,'','','','',0,'198.54.202.182','41.240.171.237','196.35.158.184',0),(149,9,'userpics/','IMG_1350.JPG',160840,213908,640,480,47,'2008-10-29 19:29:08',1222931400,2,'Donette',0,1,'Painting is serious business','','','YES',0,'','','','',0,'198.54.202.182','41.240.171.237','196.25.253.13',0),(150,9,'userpics/','IMG_1349.JPG',153587,203914,640,480,52,'2008-10-29 19:28:59',1222931422,2,'Donette',0,1,'Our attempt before being played with','','','YES',0,'','','','',0,'198.54.202.182','41.240.171.237','196.25.253.13',0),(151,9,'userpics/','IMG_1369.JPG',163757,209878,640,480,48,'2008-10-29 19:28:47',1222949607,2,'Donette',0,1,'&quot;School room&quot;','This is what I have tried to make into our school room.It is a work in progress','school','YES',0,'','','','',0,'198.54.202.182','41.240.171.237','196.25.253.13',0),(152,9,'userpics/','IMG_1368.JPG',180881,233940,480,640,60,'2008-10-29 19:28:36',1222949629,2,'Donette',0,1,'My Supply cupboard','','school','YES',0,'','','','',0,'198.54.202.182','41.240.171.237','196.25.253.13',0),(153,9,'userpics/','IMG_1367.JPG',202459,260921,640,480,59,'2008-10-29 19:28:21',1222949715,2,'Donette',0,1,'Book shelf','This is the cupboard which holds Elijah&#39;s books. We take out his choice everyday (usually a few times a day)\r\nThe crate holds his crayons, colouring books and general stuff he can pick and do on his own time ','school','YES',0,'','','','',0,'198.54.202.182','41.240.171.237','196.25.253.13',0),(154,8,'userpics/','IMG_1377.JPG',72728,122732,640,480,38,'2008-10-29 19:28:14',1223380177,2,'Donette',0,1,'A story of a Beared Dragon','(NOT REAL)','','YES',0,'','','','',0,'198.54.202.182','41.240.174.146','196.25.253.13',0),(155,9,'userpics/','IMG_1376.JPG',107063,155697,640,853,37,'2008-10-29 19:28:06',1223380198,2,'Donette',0,1,'OUr bird feeder ready and waiting','','','YES',0,'','','','',0,'198.54.202.182','41.240.174.146','196.25.253.13',0),(156,9,'userpics/','IMG_1375.JPG',64304,106323,640,480,36,'2008-10-25 21:57:18',1223380211,2,'Donette',0,1,'Work table','','','YES',0,'','','','',0,'198.54.202.182','41.240.174.146','99.168.110.23',0),(157,7,'userpics/','IMG_1373.JPG',105132,160968,640,480,43,'2008-10-25 21:56:52',1223380227,2,'Donette',0,1,'ME and Some Friends','','','YES',0,'','','','',0,'198.54.202.182','41.240.174.146','99.168.110.23',0),(158,9,'userpics/','IMG_1372.JPG',81484,135925,640,480,36,'2008-10-25 21:56:56',1223380281,2,'Donette',0,1,'Birdfeeder made with Mine and Mommy&#39;s hands','Made with Pine cone covered in Peanut Butter and rolled in bird seed','','YES',0,'','','','',0,'198.54.202.182','41.240.174.146','99.168.110.23',0);
/*!40000 ALTER TABLE `cpg_pictures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpg_plugins`
--

DROP TABLE IF EXISTS `cpg_plugins`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cpg_plugins` (
  `plugin_id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(64) NOT NULL default '',
  `path` varchar(128) NOT NULL default '',
  `priority` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`plugin_id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `path` (`path`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cpg_plugins`
--

LOCK TABLES `cpg_plugins` WRITE;
/*!40000 ALTER TABLE `cpg_plugins` DISABLE KEYS */;
/*!40000 ALTER TABLE `cpg_plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpg_sessions`
--

DROP TABLE IF EXISTS `cpg_sessions`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cpg_sessions` (
  `session_id` varchar(40) NOT NULL default '',
  `user_id` int(11) default '0',
  `time` int(11) default NULL,
  `remember` int(1) default '0',
  PRIMARY KEY  (`session_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cpg_sessions`
--

LOCK TABLES `cpg_sessions` WRITE;
/*!40000 ALTER TABLE `cpg_sessions` DISABLE KEYS */;
INSERT INTO `cpg_sessions` (`session_id`, `user_id`, `time`, `remember`) VALUES ('5894519fee3f1291f33d7f16228dbfb7',0,1225304278,0),('c26fdb0be8d06248f294cdf39f787f65',0,1225304839,0),('6ac3e26af9d51072e6c53840528bcdef',0,1225304697,0),('c11197c6ee33246b7b86147a79802cd1',0,1225305043,0),('3da6ec191ffd2bcca5a78b704a87a2fa',0,1225301927,0),('e60df34fcb442544ac101acb42eecb50',0,1225303154,0),('4baf99f59847573d37349ec3687541b7',0,1225302836,0),('209a2d158e8b4256d21c7b2e9d44d8ef',0,1225303340,0),('288483846ef0d2f4300e0394ed6e431a',0,1225304419,0),('229faf0fbbf6cc96a41b0cb71ee1b1c2',0,1225303716,0),('49b9e167ad8426b8482c795bbdde01ab',0,1225304052,0),('026dc2eb3282dfe53c0b57d2f6583fd7',0,1225302918,0),('1ab22060c3e26bf894c524740c008723',3,1225304769,1),('f2d9494d03382fc461ffb4615d3f5d7c',0,1225302695,0);
/*!40000 ALTER TABLE `cpg_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpg_temp_data`
--

DROP TABLE IF EXISTS `cpg_temp_data`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cpg_temp_data` (
  `unique_ID` char(8) NOT NULL,
  `encoded_string` blob NOT NULL,
  `timestamp` int(11) unsigned NOT NULL,
  PRIMARY KEY  (`unique_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cpg_temp_data`
--

LOCK TABLES `cpg_temp_data` WRITE;
/*!40000 ALTER TABLE `cpg_temp_data` DISABLE KEYS */;
INSERT INTO `cpg_temp_data` (`unique_ID`, `encoded_string`, `timestamp`) VALUES ('57d845a3','YToxOntpOjA7YTozOntzOjExOiJhY3R1YWxfbmFtZSI7czo4OiJ3aWw0LmpwZyI7czoxNDoidGVtcG9yYXJ5X25hbWUiO3M6MjM6Im1IVFRQX3RlbXBfMmM0MTQ5OTIuanBnIjtzOjEyOiJwcmV2aWV3X3BhdGgiO3M6MzQ6Ii4vYWxidW1zL2VkaXQvcHJldmlld182ZjcwMjM4ZS5qcGciO319',1225302959);
/*!40000 ALTER TABLE `cpg_temp_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpg_usergroups`
--

DROP TABLE IF EXISTS `cpg_usergroups`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cpg_usergroups` (
  `group_id` int(11) NOT NULL auto_increment,
  `group_name` varchar(255) NOT NULL default '',
  `group_quota` int(11) NOT NULL default '0',
  `has_admin_access` tinyint(4) NOT NULL default '0',
  `can_rate_pictures` tinyint(4) NOT NULL default '0',
  `can_send_ecards` tinyint(4) NOT NULL default '0',
  `can_post_comments` tinyint(4) NOT NULL default '0',
  `can_upload_pictures` tinyint(4) NOT NULL default '0',
  `can_create_albums` tinyint(4) NOT NULL default '0',
  `pub_upl_need_approval` tinyint(4) NOT NULL default '1',
  `priv_upl_need_approval` tinyint(4) NOT NULL default '1',
  `upload_form_config` tinyint(4) NOT NULL default '3',
  `custom_user_upload` tinyint(4) NOT NULL default '0',
  `num_file_upload` tinyint(4) NOT NULL default '5',
  `num_URI_upload` tinyint(4) NOT NULL default '3',
  PRIMARY KEY  (`group_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cpg_usergroups`
--

LOCK TABLES `cpg_usergroups` WRITE;
/*!40000 ALTER TABLE `cpg_usergroups` DISABLE KEYS */;
INSERT INTO `cpg_usergroups` (`group_id`, `group_name`, `group_quota`, `has_admin_access`, `can_rate_pictures`, `can_send_ecards`, `can_post_comments`, `can_upload_pictures`, `can_create_albums`, `pub_upl_need_approval`, `priv_upl_need_approval`, `upload_form_config`, `custom_user_upload`, `num_file_upload`, `num_URI_upload`) VALUES (1,'Administrators',0,1,1,1,1,1,1,0,0,3,0,5,3),(2,'Registered',1024,0,1,1,1,1,1,1,0,3,0,5,3),(3,'Guests',0,0,1,1,0,0,0,1,1,3,0,5,3),(4,'Banned',0,0,0,0,0,0,0,0,0,0,0,0,0);
/*!40000 ALTER TABLE `cpg_usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpg_users`
--

DROP TABLE IF EXISTS `cpg_users`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cpg_users` (
  `user_id` int(11) NOT NULL auto_increment,
  `user_group` int(11) NOT NULL default '2',
  `user_active` enum('YES','NO') NOT NULL default 'NO',
  `user_name` varchar(25) NOT NULL default '',
  `user_password` varchar(40) NOT NULL default '',
  `user_lastvisit` datetime NOT NULL default '0000-00-00 00:00:00',
  `user_regdate` datetime NOT NULL default '0000-00-00 00:00:00',
  `user_group_list` varchar(255) NOT NULL default '',
  `user_email` varchar(255) NOT NULL default '',
  `user_profile1` varchar(255) NOT NULL default '',
  `user_profile2` varchar(255) NOT NULL default '',
  `user_profile3` varchar(255) NOT NULL default '',
  `user_profile4` varchar(255) NOT NULL default '',
  `user_profile5` varchar(255) NOT NULL default '',
  `user_profile6` text NOT NULL,
  `user_actkey` varchar(32) NOT NULL default '',
  PRIMARY KEY  (`user_id`),
  UNIQUE KEY `user_name` (`user_name`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cpg_users`
--

LOCK TABLES `cpg_users` WRITE;
/*!40000 ALTER TABLE `cpg_users` DISABLE KEYS */;
INSERT INTO `cpg_users` (`user_id`, `user_group`, `user_active`, `user_name`, `user_password`, `user_lastvisit`, `user_regdate`, `user_group_list`, `user_email`, `user_profile1`, `user_profile2`, `user_profile3`, `user_profile4`, `user_profile5`, `user_profile6`, `user_actkey`) VALUES (1,1,'YES','frogzane','d72eb2dbcfa34c577688926a1a5cd7ff','2008-07-30 19:52:24','2008-06-20 16:38:12','','frogzane@frog.za.net','','','','','','',''),(2,1,'YES','Donette','3cbdeb880103c3e69e1ab78810deb84f','2008-10-22 07:44:59','2008-06-21 08:31:29','','donette.bell@frog.za.net','','','','','','',''),(3,1,'YES','william','a4dab4017ab32e3be7741b45e8307f46','2008-10-22 22:04:57','2008-07-18 17:03:43','','willliam.bell@frog.za.net','','','http://www.frog.za.net','','','','');
/*!40000 ALTER TABLE `cpg_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpg_vote_stats`
--

DROP TABLE IF EXISTS `cpg_vote_stats`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cpg_vote_stats` (
  `sid` int(11) NOT NULL auto_increment,
  `pid` varchar(100) NOT NULL default '',
  `rating` smallint(6) NOT NULL default '0',
  `ip` varchar(20) NOT NULL default '',
  `sdate` bigint(20) NOT NULL default '0',
  `referer` text NOT NULL,
  `browser` varchar(255) NOT NULL default '',
  `os` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`sid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cpg_vote_stats`
--

LOCK TABLES `cpg_vote_stats` WRITE;
/*!40000 ALTER TABLE `cpg_vote_stats` DISABLE KEYS */;
/*!40000 ALTER TABLE `cpg_vote_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpg_votes`
--

DROP TABLE IF EXISTS `cpg_votes`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cpg_votes` (
  `pic_id` mediumint(9) NOT NULL default '0',
  `user_md5_id` varchar(32) NOT NULL default '',
  `vote_time` int(11) NOT NULL default '0',
  PRIMARY KEY  (`pic_id`,`user_md5_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cpg_votes`
--

LOCK TABLES `cpg_votes` WRITE;
/*!40000 ALTER TABLE `cpg_votes` DISABLE KEYS */;
INSERT INTO `cpg_votes` (`pic_id`, `user_md5_id`, `vote_time`) VALUES (137,'97528eec7efd5883dd1abd7b3f236c25',1224429025),(146,'97528eec7efd5883dd1abd7b3f236c25',1224429010),(59,'97528eec7efd5883dd1abd7b3f236c25',1224428996),(20,'97528eec7efd5883dd1abd7b3f236c25',1224428982),(141,'97528eec7efd5883dd1abd7b3f236c25',1224428969),(54,'97528eec7efd5883dd1abd7b3f236c25',1224428953),(84,'97528eec7efd5883dd1abd7b3f236c25',1224428937),(61,'97528eec7efd5883dd1abd7b3f236c25',1224429047),(158,'97528eec7efd5883dd1abd7b3f236c25',1224429070),(157,'97528eec7efd5883dd1abd7b3f236c25',1224429170),(156,'97528eec7efd5883dd1abd7b3f236c25',1224429292),(155,'97528eec7efd5883dd1abd7b3f236c25',1224429318),(154,'97528eec7efd5883dd1abd7b3f236c25',1224429333),(153,'97528eec7efd5883dd1abd7b3f236c25',1224429350),(152,'97528eec7efd5883dd1abd7b3f236c25',1224429361),(151,'97528eec7efd5883dd1abd7b3f236c25',1224429373),(71,'97528eec7efd5883dd1abd7b3f236c25',1224429431),(55,'97528eec7efd5883dd1abd7b3f236c25',1224429447),(32,'97528eec7efd5883dd1abd7b3f236c25',1224429473),(128,'97528eec7efd5883dd1abd7b3f236c25',1224429485),(132,'97528eec7efd5883dd1abd7b3f236c25',1224429500),(94,'97528eec7efd5883dd1abd7b3f236c25',1224429519),(70,'97528eec7efd5883dd1abd7b3f236c25',1224429535),(150,'97528eec7efd5883dd1abd7b3f236c25',1224429610),(149,'97528eec7efd5883dd1abd7b3f236c25',1224429628),(148,'97528eec7efd5883dd1abd7b3f236c25',1224429647),(147,'97528eec7efd5883dd1abd7b3f236c25',1224429666),(113,'97528eec7efd5883dd1abd7b3f236c25',1224430004),(52,'97528eec7efd5883dd1abd7b3f236c25',1224430020),(115,'97528eec7efd5883dd1abd7b3f236c25',1224430036),(117,'97528eec7efd5883dd1abd7b3f236c25',1224430059),(134,'97528eec7efd5883dd1abd7b3f236c25',1224430127),(140,'97528eec7efd5883dd1abd7b3f236c25',1224430165),(142,'97528eec7efd5883dd1abd7b3f236c25',1224430208),(145,'97528eec7efd5883dd1abd7b3f236c25',1224430226),(135,'97528eec7efd5883dd1abd7b3f236c25',1224430432),(119,'97528eec7efd5883dd1abd7b3f236c25',1224430454),(82,'97528eec7efd5883dd1abd7b3f236c25',1224430467),(45,'97528eec7efd5883dd1abd7b3f236c25',1224430483),(126,'97528eec7efd5883dd1abd7b3f236c25',1224430494),(138,'97528eec7efd5883dd1abd7b3f236c25',1224430633),(131,'97528eec7efd5883dd1abd7b3f236c25',1224430669),(24,'97528eec7efd5883dd1abd7b3f236c25',1224430690),(88,'97528eec7efd5883dd1abd7b3f236c25',1224430714),(143,'97528eec7efd5883dd1abd7b3f236c25',1224430737),(116,'97528eec7efd5883dd1abd7b3f236c25',1224430873),(129,'97528eec7efd5883dd1abd7b3f236c25',1224430889),(2,'97528eec7efd5883dd1abd7b3f236c25',1224430999),(3,'97528eec7efd5883dd1abd7b3f236c25',1224431012),(4,'97528eec7efd5883dd1abd7b3f236c25',1224431023),(5,'97528eec7efd5883dd1abd7b3f236c25',1224431032),(6,'97528eec7efd5883dd1abd7b3f236c25',1224431043),(7,'97528eec7efd5883dd1abd7b3f236c25',1224431053),(8,'97528eec7efd5883dd1abd7b3f236c25',1224431065),(9,'97528eec7efd5883dd1abd7b3f236c25',1224431077),(10,'97528eec7efd5883dd1abd7b3f236c25',1224431087),(11,'97528eec7efd5883dd1abd7b3f236c25',1224431098),(12,'97528eec7efd5883dd1abd7b3f236c25',1224431114),(13,'97528eec7efd5883dd1abd7b3f236c25',1224431130),(17,'97528eec7efd5883dd1abd7b3f236c25',1224431213),(18,'97528eec7efd5883dd1abd7b3f236c25',1224431232),(19,'97528eec7efd5883dd1abd7b3f236c25',1224431245),(22,'97528eec7efd5883dd1abd7b3f236c25',1224431271),(109,'97528eec7efd5883dd1abd7b3f236c25',1224431292),(1,'97528eec7efd5883dd1abd7b3f236c25',1224431409),(28,'97528eec7efd5883dd1abd7b3f236c25',1224431422),(29,'97528eec7efd5883dd1abd7b3f236c25',1224431434),(30,'97528eec7efd5883dd1abd7b3f236c25',1224431448),(31,'97528eec7efd5883dd1abd7b3f236c25',1224431462),(33,'97528eec7efd5883dd1abd7b3f236c25',1224431479),(34,'97528eec7efd5883dd1abd7b3f236c25',1224431492),(35,'97528eec7efd5883dd1abd7b3f236c25',1224431507),(36,'97528eec7efd5883dd1abd7b3f236c25',1224431521),(37,'97528eec7efd5883dd1abd7b3f236c25',1224431536),(38,'97528eec7efd5883dd1abd7b3f236c25',1224431550),(21,'97528eec7efd5883dd1abd7b3f236c25',1224431785),(23,'97528eec7efd5883dd1abd7b3f236c25',1224431793),(25,'97528eec7efd5883dd1abd7b3f236c25',1224431804),(26,'97528eec7efd5883dd1abd7b3f236c25',1224431811),(118,'97528eec7efd5883dd1abd7b3f236c25',1224431819),(120,'97528eec7efd5883dd1abd7b3f236c25',1224431833),(121,'97528eec7efd5883dd1abd7b3f236c25',1224431841),(124,'97528eec7efd5883dd1abd7b3f236c25',1224431850),(125,'97528eec7efd5883dd1abd7b3f236c25',1224431859),(122,'97528eec7efd5883dd1abd7b3f236c25',1224432005),(123,'97528eec7efd5883dd1abd7b3f236c25',1224432026),(114,'97528eec7efd5883dd1abd7b3f236c25',1224432069),(112,'97528eec7efd5883dd1abd7b3f236c25',1224432102),(111,'97528eec7efd5883dd1abd7b3f236c25',1224432140),(110,'97528eec7efd5883dd1abd7b3f236c25',1224432172),(27,'97528eec7efd5883dd1abd7b3f236c25',1224432187),(130,'97528eec7efd5883dd1abd7b3f236c25',1224432204),(136,'97528eec7efd5883dd1abd7b3f236c25',1224432228),(133,'97528eec7efd5883dd1abd7b3f236c25',1224432270),(107,'97528eec7efd5883dd1abd7b3f236c25',1224432290),(79,'97528eec7efd5883dd1abd7b3f236c25',1224432302),(81,'97528eec7efd5883dd1abd7b3f236c25',1224432320),(78,'97528eec7efd5883dd1abd7b3f236c25',1224432353),(80,'97528eec7efd5883dd1abd7b3f236c25',1224432384),(47,'97528eec7efd5883dd1abd7b3f236c25',1224432445),(49,'97528eec7efd5883dd1abd7b3f236c25',1224432469),(46,'97528eec7efd5883dd1abd7b3f236c25',1224432491),(48,'97528eec7efd5883dd1abd7b3f236c25',1224432506),(50,'97528eec7efd5883dd1abd7b3f236c25',1224432522),(139,'97528eec7efd5883dd1abd7b3f236c25',1224432585),(51,'97528eec7efd5883dd1abd7b3f236c25',1224432668),(53,'97528eec7efd5883dd1abd7b3f236c25',1224432690),(56,'97528eec7efd5883dd1abd7b3f236c25',1224432774),(57,'97528eec7efd5883dd1abd7b3f236c25',1224432789),(65,'97528eec7efd5883dd1abd7b3f236c25',1224432992),(67,'97528eec7efd5883dd1abd7b3f236c25',1224433001),(64,'97528eec7efd5883dd1abd7b3f236c25',1224433014),(66,'97528eec7efd5883dd1abd7b3f236c25',1224433027),(68,'97528eec7efd5883dd1abd7b3f236c25',1224433036),(98,'97528eec7efd5883dd1abd7b3f236c25',1224433058),(100,'97528eec7efd5883dd1abd7b3f236c25',1224433066),(97,'97528eec7efd5883dd1abd7b3f236c25',1224433078),(99,'97528eec7efd5883dd1abd7b3f236c25',1224433088),(102,'97528eec7efd5883dd1abd7b3f236c25',1224433101),(90,'97528eec7efd5883dd1abd7b3f236c25',1224433165),(92,'97528eec7efd5883dd1abd7b3f236c25',1224433185),(89,'97528eec7efd5883dd1abd7b3f236c25',1224433205),(91,'97528eec7efd5883dd1abd7b3f236c25',1224433227),(93,'97528eec7efd5883dd1abd7b3f236c25',1224433249),(63,'97528eec7efd5883dd1abd7b3f236c25',1224433306),(144,'97528eec7efd5883dd1abd7b3f236c25',1224433512),(127,'97528eec7efd5883dd1abd7b3f236c25',1224433793),(108,'97528eec7efd5883dd1abd7b3f236c25',1224433972),(106,'97528eec7efd5883dd1abd7b3f236c25',1224433998),(105,'97528eec7efd5883dd1abd7b3f236c25',1224434015),(104,'97528eec7efd5883dd1abd7b3f236c25',1224434033),(103,'97528eec7efd5883dd1abd7b3f236c25',1224434050),(101,'97528eec7efd5883dd1abd7b3f236c25',1224434076),(96,'97528eec7efd5883dd1abd7b3f236c25',1224434127),(95,'97528eec7efd5883dd1abd7b3f236c25',1224434152),(87,'97528eec7efd5883dd1abd7b3f236c25',1224434369),(86,'97528eec7efd5883dd1abd7b3f236c25',1224434387),(85,'97528eec7efd5883dd1abd7b3f236c25',1224434415),(83,'97528eec7efd5883dd1abd7b3f236c25',1224434449),(77,'97528eec7efd5883dd1abd7b3f236c25',1224434535),(76,'97528eec7efd5883dd1abd7b3f236c25',1224434565),(75,'97528eec7efd5883dd1abd7b3f236c25',1224434590),(74,'97528eec7efd5883dd1abd7b3f236c25',1224434623),(73,'97528eec7efd5883dd1abd7b3f236c25',1224434650),(72,'97528eec7efd5883dd1abd7b3f236c25',1224434676),(69,'97528eec7efd5883dd1abd7b3f236c25',1224434720),(62,'97528eec7efd5883dd1abd7b3f236c25',1224434871),(60,'97528eec7efd5883dd1abd7b3f236c25',1224434904),(58,'97528eec7efd5883dd1abd7b3f236c25',1224434929),(44,'97528eec7efd5883dd1abd7b3f236c25',1224435078),(43,'97528eec7efd5883dd1abd7b3f236c25',1224435090),(42,'97528eec7efd5883dd1abd7b3f236c25',1224435107),(41,'97528eec7efd5883dd1abd7b3f236c25',1224435121),(40,'97528eec7efd5883dd1abd7b3f236c25',1224435140),(14,'97528eec7efd5883dd1abd7b3f236c25',1224436191),(39,'97528eec7efd5883dd1abd7b3f236c25',1224436214),(15,'97528eec7efd5883dd1abd7b3f236c25',1224436366),(16,'97528eec7efd5883dd1abd7b3f236c25',1224436382),(82,'1955525ba371839667f1704beed6c0b8',1224705752);
/*!40000 ALTER TABLE `cpg_votes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2008-10-29 18:34:18
