//
//  Copyright (C) 2005 - William Bell 
//
//  This file is part of ICalc
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//
//  Coded by William Bell
//  email: william.bell@absamail.co.za
//  Home Page: http://myweb.absamail.co.za/william.bell/
//
//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ICalc.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDD_MAINDLG                     129
#define IDC_VAR1_EDIT                   1002
#define IDC_VAR2_EDIT                   1003
#define IDC_VAR3_EDIT                   1004
#define IDC_VAR4_EDIT                   1005
#define IDC_VARNAME1_STATIC             1011
#define IDC_VARNAME2_STATIC             1012
#define IDC_VARNAME3_STATIC             1013
#define IDC_VARNAME4_STATIC             1014
#define IDC_ANSNAME_STATIC              1016
#define IDC_ANS_STATIC                  1017
#define IDC_TAB                         1018
#define IDC_HELP_STATIC                 1019

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        204
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
