//
//  Copyright (C) 2005 - William Bell 
//
//  This file is part of ICalc
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//
//  Coded by William Bell
//  email: william.bell@absamail.co.za
//  Home Page: http://myweb.absamail.co.za/william.bell/
//
// maindlg.h : interface of the CMainDlg class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINDLG_H__520F6D4E_BA51_11D4_9632_0080C87F47A1__INCLUDED_)
#define AFX_MAINDLG_H__520F6D4E_BA51_11D4_9632_0080C87F47A1__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

static char* csFV =  {"Final Amount"};
static char* csFVt = {"The final amount after term."};
static char* csFVa = {"Calculates the final amount after the term completes."};
static char* csPV =  {"Initial Amount"};
static char* csPVt = {"The initial amount. (deposit)"};
static char* csPVa = {"Calculates the initial amount exchanged on day one of the deal."};
static char* csPMT = {"Installment"};
static char* csPMTt = {"The monthly amount."};
static char* csPMTa = {"Calculates the amount exchanged every month."};
static char* csI =  {"Interest per Year"};
static char* csIt = {"The interest per year."};
static char* csIa = {"Calculates interest per year."};
static char* csN =  {"Number of months."};
static char* csNt = {"The number of months."};
static char* csNa = {"Calculates the number of months."};

class CMainDlg : public CDialogImpl<CMainDlg>, public CUpdateUI<CMainDlg>,	public CMessageFilter
{
public:
	enum { IDD = IDD_MAINDLG };

	CToolTipCtrl m_tool;
	CTabCtrl m_TabCntr;
	CStatic m_VarName1;
	CStatic m_VarName2;
	CStatic m_VarName3;
	CStatic m_VarName4;
	CStatic m_AnsName;
	CEdit m_Var1;
	CEdit m_Var2;
	CEdit m_Var3;
	CEdit m_Var4;
	CStatic m_Answer;
	int m_calc;

	virtual BOOL PreTranslateMessage(MSG* pMsg)
	{
		m_tool.RelayEvent(pMsg);
		if (pMsg->message == WM_SYSCOMMAND && pMsg->wParam == ID_APP_ABOUT)
		{
			CAboutDlg dlg;
			dlg.DoModal();
		}
		return IsDialogMessage(pMsg);
	}

	BEGIN_MSG_MAP(CMainDlg)
		MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
//		COMMAND_ID_HANDLER(ID_APP_ABOUT, OnAppAbout)
		COMMAND_ID_HANDLER(IDOK, OnOK)
		COMMAND_ID_HANDLER(IDCANCEL, OnCancel)
		NOTIFY_HANDLER(IDC_TAB, TCN_SELCHANGE, OnSelchangeTab)
		COMMAND_HANDLER(IDC_VAR1_EDIT, EN_CHANGE, OnChangeVar1_edit)
		COMMAND_HANDLER(IDC_VAR2_EDIT, EN_CHANGE, OnChangeVar2_edit)
		COMMAND_HANDLER(IDC_VAR3_EDIT, EN_CHANGE, OnChangeVar3_edit)
		COMMAND_HANDLER(IDC_VAR4_EDIT, EN_CHANGE, OnChangeVar4_edit)
	END_MSG_MAP()

	BEGIN_UPDATE_UI_MAP(CMainDlg)
	END_UPDATE_UI_MAP()

	LRESULT OnInitDialog(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
	{
		// center the dialog on the screen
		CenterWindow();

		// set icons
		HICON hIcon = (HICON)::LoadImage(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDR_MAINFRAME), 
			IMAGE_ICON, ::GetSystemMetrics(SM_CXICON), ::GetSystemMetrics(SM_CYICON), LR_DEFAULTCOLOR);
		SetIcon(hIcon, TRUE);
		HICON hIconSmall = (HICON)::LoadImage(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDR_MAINFRAME), 
			IMAGE_ICON, ::GetSystemMetrics(SM_CXSMICON), ::GetSystemMetrics(SM_CYSMICON), LR_DEFAULTCOLOR);
		SetIcon(hIconSmall, FALSE);

		// register object for message filtering and idle updates
		CMessageLoop* pLoop = _Module.GetMessageLoop();
		ATLASSERT(pLoop != NULL);
		pLoop->AddMessageFilter(this);

		UIAddChildWindowContainer(m_hWnd);

		m_TabCntr.Attach(GetDlgItem(IDC_TAB));
		m_VarName1.Attach(GetDlgItem(IDC_VARNAME1_STATIC));
		m_VarName2.Attach(GetDlgItem(IDC_VARNAME2_STATIC));
		m_VarName3.Attach(GetDlgItem(IDC_VARNAME3_STATIC));
		m_VarName4.Attach(GetDlgItem(IDC_VARNAME4_STATIC));
		m_AnsName.Attach(GetDlgItem(IDC_ANSNAME_STATIC));
		m_Var1.Attach(GetDlgItem(IDC_VAR1_EDIT));
		m_Var2.Attach(GetDlgItem(IDC_VAR2_EDIT));
		m_Var3.Attach(GetDlgItem(IDC_VAR3_EDIT));
		m_Var4.Attach(GetDlgItem(IDC_VAR4_EDIT));
		m_Answer.Attach(GetDlgItem(IDC_ANS_STATIC));

		char* pInitValueName[6];
		TCITEM itemAttrib;
		itemAttrib.mask = TCIF_TEXT;

		pInitValueName[0] = csPMT;
		itemAttrib.cchTextMax = strlen(pInitValueName[0]);
		itemAttrib.pszText = pInitValueName[0];
		m_TabCntr.InsertItem(0, &itemAttrib);

		pInitValueName[1] = "Final";
		itemAttrib.cchTextMax = strlen(pInitValueName[1]);
		itemAttrib.pszText = pInitValueName[1];
		m_TabCntr.InsertItem(1, &itemAttrib);

		pInitValueName[2] = "Initial";
		itemAttrib.cchTextMax = strlen(pInitValueName[2]);
		itemAttrib.pszText = pInitValueName[2];
		m_TabCntr.InsertItem(2, &itemAttrib);

		pInitValueName[3] = "Interest";
		itemAttrib.cchTextMax = strlen(pInitValueName[3]);
		itemAttrib.pszText = pInitValueName[3];
		m_TabCntr.InsertItem(3, &itemAttrib);

		pInitValueName[4] = "Months";
		itemAttrib.cchTextMax = strlen(pInitValueName[4]);
		itemAttrib.pszText = pInitValueName[4];
		m_TabCntr.InsertItem(4, &itemAttrib);

		m_VarName1.SetWindowText(csPV);
		m_VarName2.SetWindowText(csI);
		m_VarName3.SetWindowText(csN);
		m_VarName4.SetWindowText(csFV);
		m_AnsName.SetWindowText(csPMT);
		m_calc = 0;

		// add the minimize command to the system menu
		HMENU mu = GetSystemMenu( FALSE );
		InsertMenu(mu, -1, MF_SEPARATOR, NULL, NULL);
		InsertMenu(mu, -1, MF_BYPOSITION, ID_APP_ABOUT, "&About" );

		// Tool tips
		m_tool.Create(m_hWnd);
		m_tool.AddTool(m_Var1, csPVt);
		m_tool.AddTool(m_Var2, csIt);
		m_tool.AddTool(m_Var3, csNt);
		m_tool.AddTool(m_Var4, csFVt);
		m_tool.AddTool(m_Answer, csPMTa);
		m_tool.SetDelayTime(TTDT_AUTOPOP, 5000);
		m_tool.SetMaxTipWidth(200);
		m_tool.Activate(TRUE);
		return TRUE;
	}

//	LRESULT OnAppAbout(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
//	{
//		CAboutDlg dlg;
//		dlg.DoModal();
//		return 0;
//	}

	LRESULT OnOK(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		// TODO: Add validation code
		// The tab key changes the focus of the controls by default 
		// do this with the enter key aswell
		HWND hwndTest = GetFocus();
		if (hwndTest) 
		{
			PostMessage(WM_NEXTDLGCTL, 0, 0L) ;
		}

		return 0;
	}

	LRESULT OnCancel(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		CloseDialog(wID);
		return 0;
	}

	void CloseDialog(int nVal)
	{
		DestroyWindow();
		::PostQuitMessage(nVal);
	}
	LRESULT OnSelchangeTab(int idCtrl, LPNMHDR pnmh, BOOL& bHandled)
	{
		// TODO : Add Code for control notification handler.
//		CTabCtrl::GetCurSel()::
		switch (m_TabCntr.GetCurSel())
		{
		case 0:
			m_VarName1.SetWindowText(csPV);
			m_VarName2.SetWindowText(csI);
			m_VarName3.SetWindowText(csN);
			m_VarName4.SetWindowText(csFV);
			m_AnsName.SetWindowText(csPMT);
			m_tool.DelTool(m_Var1);
			m_tool.DelTool(m_Var2);
			m_tool.DelTool(m_Var3);
			m_tool.DelTool(m_Var4);
			m_tool.DelTool(m_Answer);
			m_tool.AddTool(m_Var1, csPVt);
			m_tool.AddTool(m_Var2, csIt);
			m_tool.AddTool(m_Var3, csNt);
			m_tool.AddTool(m_Var4, csFVt);
			m_tool.AddTool(m_Answer, csPMTa);

			m_calc = 0;
			break;
		case 1:
			m_VarName1.SetWindowText(csPV);
			m_VarName2.SetWindowText(csI);
			m_VarName3.SetWindowText(csN);
			m_VarName4.SetWindowText(csPMT);
			m_AnsName.SetWindowText(csFV);
			m_tool.DelTool(m_Var1);
			m_tool.DelTool(m_Var2);
			m_tool.DelTool(m_Var3);
			m_tool.DelTool(m_Var4);
			m_tool.DelTool(m_Answer);
			m_tool.AddTool(m_Var1, csPVt);
			m_tool.AddTool(m_Var2, csIt);
			m_tool.AddTool(m_Var3, csNt);
			m_tool.AddTool(m_Var4, csPMTt);
			m_tool.AddTool(m_Answer, csFVa);
			m_calc = 1;
			break;
		case 2:
			m_VarName1.SetWindowText(csFV);
			m_VarName2.SetWindowText(csI);
			m_VarName3.SetWindowText(csN);
			m_VarName4.SetWindowText(csPMT);
			m_AnsName.SetWindowText(csPV);
			m_tool.DelTool(m_Var1);
			m_tool.DelTool(m_Var2);
			m_tool.DelTool(m_Var3);
			m_tool.DelTool(m_Var4);
			m_tool.DelTool(m_Answer);
			m_tool.AddTool(m_Var1, csFVt);
			m_tool.AddTool(m_Var2, csIt);
			m_tool.AddTool(m_Var3, csNt);
			m_tool.AddTool(m_Var4, csPMTt);
			m_tool.AddTool(m_Answer, csPVa);
			m_calc = 2;
			break;
		case 3:		// interest
			m_VarName1.SetWindowText(csPV);
			m_VarName2.SetWindowText(csFV);
			m_VarName3.SetWindowText(csN);
			m_VarName4.SetWindowText(csPMT);
			m_AnsName.SetWindowText(csI);
			m_tool.DelTool(m_Var1);
			m_tool.DelTool(m_Var2);
			m_tool.DelTool(m_Var3);
			m_tool.DelTool(m_Var4);
			m_tool.DelTool(m_Answer);
			m_tool.AddTool(m_Var1, csPVt);
			m_tool.AddTool(m_Var2, csFVt);
			m_tool.AddTool(m_Var3, csNt);
			m_tool.AddTool(m_Var4, csPMTt);
			m_tool.AddTool(m_Answer, csIa);
			m_calc = 3;
			break;
		case 4:	 // monthly
			m_VarName1.SetWindowText(csPV);
			m_VarName2.SetWindowText(csI);
			m_VarName3.SetWindowText(csFV);
			m_VarName4.SetWindowText(csPMT);
			m_AnsName.SetWindowText(csN);
			m_tool.DelTool(m_Var1);
			m_tool.DelTool(m_Var2);
			m_tool.DelTool(m_Var3);
			m_tool.DelTool(m_Var4);
			m_tool.DelTool(m_Answer);
			m_tool.AddTool(m_Var1, csPVt);
			m_tool.AddTool(m_Var2, csIt);
			m_tool.AddTool(m_Var3, csFVt);
			m_tool.AddTool(m_Var4, csPMTt);
			m_tool.AddTool(m_Answer, csNa);
			m_calc = 4;
			break;
		}
		return 0;
	}
	LRESULT OnChangeVar1_edit(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		// TODO : Add Code for control notification handler.
		UpdateCalculation();
		return 0;
	}
	LRESULT OnChangeVar2_edit(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		// TODO : Add Code for control notification handler.
		UpdateCalculation();
		return 0;
	}
	LRESULT OnChangeVar3_edit(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		// TODO : Add Code for control notification handler.
		UpdateCalculation();
		return 0;
	}
	LRESULT OnChangeVar4_edit(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		// TODO : Add Code for control notification handler.
		UpdateCalculation();
		return 0;
	}
	LRESULT OnChangeVar5_edit(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		// TODO : Add Code for control notification handler.
		UpdateCalculation();
		return 0;
	}

	void UpdateCalculation()
	{
		static char data[64];
		double i,a,b,c,d;
		double x = 0.0;
		m_Var1.GetWindowText(data, 64);
		a = atof(data);
		m_Var2.GetWindowText(data, 64);
		b = atof(data);
		m_Var3.GetWindowText(data, 64);
		c = atof(data);
		m_Var4.GetWindowText(data, 64);
		d = atof(data);

		switch (m_calc)
		{
		case 0:	// Installment
			if (b != 0)
			{
				i = b/1200;
				x = (-a-d*pow((1+i), -c))*i / (1-pow((1+i), -c));
			}
			else
			{
				x = (a+d)/-c;
			}
			break;
		case 1:	// Final Amount
			if (b != 0)
			{
				i = b/1200;
				x = (-a-d*(1-pow((1+i), -c))/i) / pow((1+i), -c);
			}
			else
			{
				x = -d*c-a;
			}
			break;
		case 2:	// Initial Amount
			if (b != 0)
			{
				i = b/1200.;
				x = -d*(1-pow((1+i), -c))/i - a*pow((1+i),-c);
			}
			else
			{
				x = -c*d-a;
			}
			break;
		case 3:	// Interest per year
				// The formula is a polonimial equation (many possable roots) so we have
				// to guess the answer
			if (0 != -c*d - b - a)
				x = findInterest(a,b,c,d);
			else
				x = 0;
			break;
		case 4:	// Number of installments
			if (b != 0)
			{
				i = b/1200.;
				x = log10((-a*i-d)/(c*i-d))/-log10(1+i);
			}
			else
			{
				x = (c+a)/-d;
			}

			break;
		case 5:
			break;
		}
//		sprintf(data, "%.2f", x);
		gcvt(x, 10, data );

		char* p;
		for (p=data; *p!='.' && *p != 0; p++);
		*(p+3) = 0;
		m_Answer.SetWindowText(data);
//		int  decimal, sign;
//		m_Answer.SetWindowText(fcvt(x, 2, &decimal, &sign ));
	}
	//-------------------------------------------------------------------------
	inline double findInterest(double a, double b, double c, double d)
	{
		double gh, gl, i, resl, resh, res, prevRes;
		int count = 0;
		res = prevRes = 0;
		gh = 0.009; gl=-0.009;
		i = gl;
		resl = a + d*(1-pow(1+i, -c))/i + b*pow(1+i, -c);
		i = gh;
		resh = a + d*(1-pow(1+i, -c))/i + b*pow(1+i, -c);
		prevRes = resl; 
		res = resh;
		ATLTRACE("\nStart   resl:%.4f resh:%f i:%.4f gl=%f, gh=%f\n", resl, resh,  i, gl, gh);
		count = 0;
		if (fabs(resl) < fabs(resh))
		{
			while (gl != gh && resl*resh > 0 && fabs(resl) < fabs(resh) && count < 100)
			{
				ATLTRACE("Smaller resl:%.4f resh:%f i:%.4f gl=%f, gh=%f\n", resl, resh,  i, gl, gh);
				resh = resl;
				gh = gl;
				gl *= 2;
				i = gl;
				resl = a + d*(1-pow(1+i, -c))/i + b*pow(1+i, -c);
				count++;
				if (gh == gl) count = 100;
			}
		}
//		if (fabs(resl) >= fabs(resh) && (count == 100 || count == 0))
		else
		{
			while (gl != gh && resl*resh > 0 && fabs(resl) > fabs(resh) && count < 100)
			{
				ATLTRACE("Bigger  resl:%.4f resh:%f i:%.4f gl=%f, gh=%f\n", resl, resh,  i, gl, gh);
				resl = resh;
				gl = gh;
				gh *= 2;
				i = gh;
				resh = a + d*(1-pow(1+i, -c))/i + b*pow(1+i, -c);
				count++;
			}
		}
		// if res is close to the PV we chose wrong as we have platued out to here.
		// if gl==gh and res != 0 then we chose the wrong direction 
		// we should search in the other direction if this happens.
		ATLTRACE("Final   resl:%.4f resh:%f i:%.4f gl=%f, gh=%f count=%d\n", resl, resh,  i, gl, gh, count);
		if (count < 100)
		{
			count = 0;
			while (res != 0 && count < 100)
			{
				if (gl*gh > 0)				// both negative or both positive
					i = gl+(gh-gl)/2;
				else
					i = gl+(gh-gl)*0.75;	// we want to avoid getting i==0

				res = a + d*(1-pow(1+i, -c))/i + b*pow(1+i, -c);
				if (res*resl < 0) 	// answer lies between thease values
				{
					ATLTRACE("gh  resl:%.4f resh:%f i:%.4f gl=%f, gh=%f\n", resl, resh,  i, gl, gh);
					gh = i;
					resh = res;
				}
				else if (res*resh < 0)
				{
					ATLTRACE("gl  resl:%.4f resh:%f i:%.4f gl=%f, gh=%f\n", resl, resh,  i, gl, gh);
					gl = i;
					resl = res;
				}
				else if (fabs(resh-res) < fabs(res-resl)) 	// answer lies between thease values
				{
					ATLTRACE("gh  resl:%.4f resh:%f i:%.4f gl=%f, gh=%f\n", resl, resh,  i, gl, gh);
					gh = i;
					resh = res;
				}
				else
				{
					ATLTRACE("gl  resl:%.4f resh:%f i:%.4f gl=%f, gh=%f\n", resl, resh,  i, gl, gh);
					gl = i;
					resl = res;
				}
				ATLTRACE("g   resl:%.4f resh:%f i:%.4f gl=%f, gh=%f\n", resl, resh,  i, gl, gh);
				count++;
			}
		}
		return i*1200;
	}
};

/////////////////////////////////////////////////////////////////////////////
/*
	//-------------------------------------------------------------------------
	inline double findInterest(double a, double b, double c, double d)
	{
		double gh, gl, i, resl, resh, res, prevRes;
		int count = 0;
		int investment;
		res = prevRes = 0;
		// get the total money we put in
		double totalIn = 0;
		double totalOut = 0;
		if (d < 0) totalIn = d*c;	else totalOut = d*c;
		if (b < 0) totalIn += b;	else totalOut += b;
		if (a < 0) totalIn += a;	else totalOut +=a;

		// do we have a negative interest rate?
//		if (d*c < 0)		// we are making monthly payments
		if (totalIn > totalOut)
		{
			investment = -1;
		}
//		else if (d*c > 0)	// we are getting monthly payments
		else if (totalIn < totalOut)
		{
			investment = 1;
		}
		else
		{
			return 0;
		}

		if (totalIn == 0)
		{
			return 1/totalIn;
		}
		else if (totalOut == 0)
		{
			return -1/totalOut;
		}

		// first calculate at zero percent
		if (0 < investment*(c*d + b + a))	// positive interest
		{
			gh = 0.009; gl=1e-9;
		}
		else if (0 > investment*(c*d + b + a))	// negative interest rate
		{
			gh = -1e-9; gl=-0.009;
		}
		else
		{
			return 0;	// no interest 
		}

		i = gl;
		resl = a + d*(1-pow(1+i, -c))/i + b*pow(1+i, -c);
		i = gh;
		resh = a + d*(1-pow(1+i, -c))/i + b*pow(1+i, -c);
		prevRes = resl; 
		res = resh;
		ATLTRACE("\nStart   resl:%.4f resh:%f i:%.4f gl=%f, gh=%f\n", resl, resh,  i, gl, gh);
		count = 0;
		if (fabs(resl) < fabs(resh))
		{
			while (gl != gh && resl*resh > 0 && fabs(resl) < fabs(resh) && count < 100)
			{
				ATLTRACE("Smaller resl:%.4f resh:%f i:%.4f gl=%f, gh=%f\n", resl, resh,  i, gl, gh);
				resh = resl;
				gh = gl;
				gl *= 2;
				i = gl;
				resl = a + d*(1-pow(1+i, -c))/i + b*pow(1+i, -c);
				count++;
				if (gh == gl) count = 100;
			}
		}
//		if (fabs(resl) >= fabs(resh) && (count == 100 || count == 0))
		else
		{
			while (gl != gh && resl*resh > 0 && fabs(resl) > fabs(resh) && count < 100)
			{
				ATLTRACE("Bigger  resl:%.4f resh:%f i:%.4f gl=%f, gh=%f\n", resl, resh,  i, gl, gh);
				resl = resh;
				gl = gh;
				gh *= 2;
				i = gh;
				resh = a + d*(1-pow(1+i, -c))/i + b*pow(1+i, -c);
				count++;
			}
		}
		// if res is close to the PV we chose wrong as we have platued out to here.
		// if gl==gh and res != 0 then we chose the wrong direction 
		// we should search in the other direction if this happens.
		ATLTRACE("Final   resl:%.4f resh:%f i:%.4f gl=%f, gh=%f count=%d\n", resl, resh,  i, gl, gh, count);
		if (count < 100)
		{
			count = 0;
			while (res != 0 && count < 100)
			{
				i = gl+(gh-gl)/2.0;
				res = a + d*(1-pow(1+i, -c))/i + b*pow(1+i, -c);
				if (res*resl < 0) 	// answer lies between thease values
				{
					ATLTRACE("gh  resl:%.4f resh:%f i:%.4f gl=%f, gh=%f\n", resl, resh,  i, gl, gh);
					gh = i;
					resh = res;
				}
				else if (res*resh < 0)
				{
					ATLTRACE("gl  resl:%.4f resh:%f i:%.4f gl=%f, gh=%f\n", resl, resh,  i, gl, gh);
					gl = i;
					resl = res;
				}
				else if (fabs(resh-res) < fabs(res-resl)) 	// answer lies between thease values
				{
					ATLTRACE("gh  resl:%.4f resh:%f i:%.4f gl=%f, gh=%f\n", resl, resh,  i, gl, gh);
					gh = i;
					resh = res;
				}
				else
				{
					ATLTRACE("gl  resl:%.4f resh:%f i:%.4f gl=%f, gh=%f\n", resl, resh,  i, gl, gh);
					gl = i;
					resl = res;
				}
				ATLTRACE("g   resl:%.4f resh:%f i:%.4f gl=%f, gh=%f\n", resl, resh,  i, gl, gh);
				count++;
			}
		}
		return i*1200;
	}
};
*/
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINDLG_H__520F6D4E_BA51_11D4_9632_0080C87F47A1__INCLUDED_)
