// ICalc.h
