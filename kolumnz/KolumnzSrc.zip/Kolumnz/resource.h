//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Kolumnz.rc
//
#define IDC_OK_BUTTON                   1
#define IDD_ENTERHIGHSCORE              3
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDD_HIGHSCORETABLE              131
#define IDD_OPTIONS_DIALOG              132
#define IDR_BOGUSICON                   133
#define IDD_CONTROLS_DIALOG             134
#define IDB_SCREEN0                     135
#define IDB_SCREEN1                     136
#define IDB_SCREEN2                     137
#define IDB_SCREEN3                     138
#define IDB_SCREEN4                     139
#define IDB_SCREEN5                     140
#define IDB_SCREEN6                     141
#define IDB_SCREEN7                     142
#define IDB_SCREEN8                     143
#define IDB_SCREEN9                     144
#define IDC_CLEARCURSOR                 145
#define IDC_NAME                        200
#define IDC_QUOTE                       201
#define IDD_PROPERTIES                  202
#define IDD_NEWGAME_DIALOG              203
#define IDC_TITLE_STATIC                1000
#define IDC_GRIDVERTICAL_CHECK          1001
#define IDC_SCORE_STATIC                1002
#define IDC_GRIDHORIZONTAL_CHECK        1003
#define IDC_TITLE_EDIT                  1004
#define IDC_RANK_STATIC                 1005
#define IDC_RADIO3                      1006
#define IDC_PENALIZE_CHECK              1007
#define IDC_LEFT1_HOTKEY                1008
#define IDC_BLOCKS_STATIC               1009
#define IDC_RIGHT1_HOTKEY               1010
#define IDC_LEVEL_STATIC                1011
#define IDC_DROP1_HOTKEY                1012
#define IDC_DATE_STATIC                 1013
#define IDC_ENDLEVEL_SPIN               1014
#define IDC_ROTATE1_HOTKEY              1015
#define IDC_NAME_STATIC                 1016
#define IDC_ENDLEVEL_EDIT               1017
#define IDC_LEFT2_HOTKEY                1018
#define IDC_QUOTE_STATIC                1019
#define IDC_RIGHT2_HOTKEY               1020
#define IDC_DROP2_HOTKEY                1021
#define IDC_ROTATE2_HOTKEY              1022
#define IDC_DOWN1_HOTKEY                1023
#define IDC_DEFAULTS_BUTTON             1024
#define IDC_DOWN2_HOTKEY                1025
#define IDC_GRID_STATIC                 1026
#define IDC_BLOCKSIZE_STATIC            1027
#define IDC_BLOCKCOMPLEX_STATIC         1028
#define IDC_LEVELLIMIT_STATIC           1029
#define IDC_PIECESTYLE_RADIO            1030
#define IDC_RADIO2                      1031
#define IDC_KEYBOARD_BUTTON             1032
#define IDC_PLAYERS_RADIO               2000
#define IDC_RADIO8                      2001
#define IDC_PREVEIW_CHECK               2002
#define IDC_SOUND_CHECK                 2004
#define IDC_LEVEL_EDIT                  2007
#define IDC_LEVEL_SPIN                  2008
#define IDC_BASE_EDIT                   2009
#define IDC_BASE_SPIN                   2010
#define IDC_COLORS_EDIT                 2011
#define IDC_HEIGHT_EDIT                 2012
#define IDC_HEIGHT_SPIN                 2013
#define IDC_COLORS_SPIN                 2014
#define IDC_LENGTH_SPIN                 2015
#define IDC_LENGTH_EDIT                 2016
#define IDC_ROWS_SPIN                   2020
#define IDC_ROWS_EDIT                   2021
#define ID_GAME_PAUSEF3                 32771
#define ID_GAME_HIGHSCORES              32772
#define ID_GAME_PLAY                    32773
#define ID_FILE_KOLUMNZMANIA            32775
#define ID_FILE_COOLKOLUMNZ             32779
#define ID_FILE_CLASSICKOLUMNZ          32780
#define ID_FILE_JUNIORKOLUMNZ           32781
#define ID_BUTTON32782                  32782
#define ID_HELP_CONTENTS                32783
#define ID_GAME_PROPERTIES              32784
#define ID_OPTIONS_CUSTOMIZE            32788

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        207
#define _APS_NEXT_COMMAND_VALUE         32789
#define _APS_NEXT_CONTROL_VALUE         1033
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
